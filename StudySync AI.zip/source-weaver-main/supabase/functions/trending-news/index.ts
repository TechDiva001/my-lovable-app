const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface StudyPackItem {
  title: string;
  description: string;
  url: string;
  image: string | null;
  source: string;
  publishedAt: string;
  category: string;
  type: 'course' | 'exam-prep' | 'tutorial' | 'research' | 'quiz';
}

// Education-focused search topics
const EDUCATION_TOPICS = [
  'online course tutorial 2024',
  'exam preparation tips study',
  'crash course education',
  'study guide academic',
  'quiz practice test',
  'machine learning course',
  'programming tutorial beginner',
  'math study guide',
  'science education',
  'history crash course',
  'language learning tips',
  'certification exam prep',
];

// Study pack type mapping based on keywords
function determinePackType(title: string, description: string): StudyPackItem['type'] {
  const text = (title + ' ' + description).toLowerCase();
  if (text.includes('exam') || text.includes('test prep') || text.includes('certification')) return 'exam-prep';
  if (text.includes('quiz') || text.includes('practice')) return 'quiz';
  if (text.includes('course') || text.includes('lesson') || text.includes('class')) return 'course';
  if (text.includes('research') || text.includes('study') || text.includes('paper')) return 'research';
  return 'tutorial';
}

// Parse Google News RSS feed with education focus
async function fetchEducationNews(topic: string): Promise<StudyPackItem[]> {
  const url = `https://news.google.com/rss/search?q=${encodeURIComponent(topic)}&hl=en-US&gl=US&ceid=US:en`;
  
  try {
    const response = await fetch(url);
    const xml = await response.text();
    
    const items: StudyPackItem[] = [];
    const itemRegex = /<item>([\s\S]*?)<\/item>/g;
    let match;
    
    while ((match = itemRegex.exec(xml)) !== null && items.length < 4) {
      const itemXml = match[1];
      const title = extractTag(itemXml, 'title');
      const link = extractTag(itemXml, 'link');
      const pubDate = extractTag(itemXml, 'pubDate');
      const source = extractTag(itemXml, 'source');
      const description = extractTag(itemXml, 'description');
      
      // Extract image from description HTML
      const imgMatch = description?.match(/<img[^>]+src="([^"]+)"/);
      const image = imgMatch ? imgMatch[1] : null;

      if (title) {
        const cleanTitle = decodeHtmlEntities(title);
        const cleanDesc = description 
          ? decodeHtmlEntities(description.replace(/<[^>]*>/g, '').trim()).slice(0, 200) 
          : '';
        
        items.push({
          title: cleanTitle,
          description: cleanDesc,
          url: link || '',
          image,
          source: source ? decodeHtmlEntities(source) : 'Education',
          publishedAt: pubDate || new Date().toISOString(),
          category: topic,
          type: determinePackType(cleanTitle, cleanDesc),
        });
      }
    }
    
    return items;
  } catch (error) {
    console.error(`Error fetching topic ${topic}:`, error);
    return [];
  }
}

function extractTag(xml: string, tag: string): string | null {
  const cdataRegex = new RegExp(`<${tag}[^>]*><!\\[CDATA\\[([\\s\\S]*?)\\]\\]><\\/${tag}>`);
  const cdataMatch = xml.match(cdataRegex);
  if (cdataMatch) return cdataMatch[1];
  
  const regex = new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`);
  const match = xml.match(regex);
  return match ? match[1].trim() : null;
}

function decodeHtmlEntities(str: string): string {
  return str
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&apos;/g, "'");
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Pick 3-4 random education topics for variety
    const shuffled = [...EDUCATION_TOPICS].sort(() => Math.random() - 0.5);
    const selectedTopics = shuffled.slice(0, 4);
    
    // Fetch education-focused content in parallel
    const results = await Promise.all(
      selectedTopics.map(topic => fetchEducationNews(topic))
    );

    // Flatten and deduplicate
    const allItems = results.flat();
    const seen = new Set<string>();
    const unique = allItems.filter(item => {
      const key = item.title.toLowerCase();
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    }).slice(0, 12);

    // Shuffle for variety
    const shuffledItems = unique.sort(() => Math.random() - 0.5);

    return new Response(
      JSON.stringify({ success: true, data: shuffledItems }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error fetching study packs:', error);
    return new Response(
      JSON.stringify({ success: false, error: 'Failed to fetch study packs' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
