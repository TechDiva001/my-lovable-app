
-- Create storage bucket for workspace source files
INSERT INTO storage.buckets (id, name, public, file_size_limit)
VALUES ('workspace-sources', 'workspace-sources', false, 20971520)
ON CONFLICT (id) DO NOTHING;

-- Allow authenticated users to upload files to their own folder
CREATE POLICY "Users can upload source files"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'workspace-sources'
  AND (storage.foldername(name))[1] = auth.uid()::text
);

-- Allow authenticated users to read their own files
CREATE POLICY "Users can read own source files"
ON storage.objects FOR SELECT
TO authenticated
USING (
  bucket_id = 'workspace-sources'
  AND (storage.foldername(name))[1] = auth.uid()::text
);

-- Allow authenticated users to delete their own files
CREATE POLICY "Users can delete own source files"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'workspace-sources'
  AND (storage.foldername(name))[1] = auth.uid()::text
);
