import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { signOut } from "@/lib/auth";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { motion, AnimatePresence } from "framer-motion";
import {
  Zap, Plus, LogOut, Search, Clock, Settings,
  MoreVertical, Trash2, Pencil, LayoutGrid, List,
  ChevronRight, ChevronDown, Globe, Loader2, ExternalLink, TrendingUp
} from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";

type Workspace = {
  id: string;
  title: string;
  description: string | null;
  created_at: string;
  source_count?: number;
};

type NewsItem = {
  title: string;
  description: string;
  url: string;
  image: string | null;
  source: string;
  publishedAt: string;
  category: string;
};

const getWorkspaceEmoji = (title: string): string => {
  const lower = title.toLowerCase();
  const emojiMap: [string[], string][] = [
    [["database", "sql", "data", "storage"], "🗄️"],
    [["biology", "bio", "cell", "dna", "genetics"], "🧬"],
    [["chemistry", "chem", "molecule", "atom"], "⚗️"],
    [["physics", "quantum", "gravity", "energy"], "⚛️"],
    [["math", "calculus", "algebra", "geometry"], "📐"],
    [["history", "war", "ancient", "civilization"], "🏛️"],
    [["computer", "programming", "code", "software", "ict", "tech"], "💻"],
    [["psychology", "mind", "mental", "brain", "cognitive"], "🧠"],
    [["education", "school", "learning", "teach", "student"], "🎓"],
    [["research", "study", "analysis", "methodology"], "🔬"],
    [["security", "cyber", "encrypt", "protect"], "🛡️"],
    [["business", "market", "finance", "economic"], "📊"],
    [["art", "design", "creative", "visual"], "🎨"],
    [["music", "audio", "sound", "song"], "🎵"],
    [["language", "english", "french", "spanish", "writing"], "✍️"],
    [["health", "medical", "medicine", "doctor"], "🏥"],
    [["law", "legal", "justice", "court"], "⚖️"],
    [["philosophy", "ethics", "logic"], "💭"],
    [["geography", "earth", "climate", "environment"], "🌍"],
    [["guide", "tutorial", "how to", "manual"], "📖"],
    [["trend", "future", "innovation"], "📈"],
    [["exam", "test", "quiz", "assessment"], "📝"],
    [["principle", "fundamental", "foundation"], "📚"],
  ];
  for (const [keywords, emoji] of emojiMap) {
    if (keywords.some((k) => lower.includes(k))) return emoji;
  }
  const fallbacks = ["📓", "📒", "📕", "📗", "📘", "📙", "📔"];
  return fallbacks[title.length % fallbacks.length];
};

const getWorkspaceGradient = (title: string): string => {
  const gradients = [
    "from-violet-600/20 to-indigo-600/20",
    "from-rose-600/20 to-pink-600/20",
    "from-emerald-600/20 to-teal-600/20",
    "from-amber-600/20 to-orange-600/20",
    "from-sky-600/20 to-cyan-600/20",
    "from-fuchsia-600/20 to-purple-600/20",
    "from-lime-600/20 to-green-600/20",
    "from-red-600/20 to-rose-600/20",
  ];
  const idx = title.split("").reduce((a, c) => a + c.charCodeAt(0), 0) % gradients.length;
  return gradients[idx];
};

type ViewMode = "grid" | "list";
type Tab = "all" | "my" | "featured";
type SortBy = "recent" | "alpha" | "sources";

const Dashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [workspaces, setWorkspaces] = useState<Workspace[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [renameId, setRenameId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [viewMode, setViewMode] = useState<ViewMode>("grid");
  const [activeTab, setActiveTab] = useState<Tab>("all");
  const [sortBy, setSortBy] = useState<SortBy>("recent");
  const [trendingNews, setTrendingNews] = useState<NewsItem[]>([]);
  const [newsLoading, setNewsLoading] = useState(true);
  const [creatingFromNews, setCreatingFromNews] = useState<string | null>(null);

  useEffect(() => {
    fetchWorkspaces();
    fetchTrendingNews();
  }, []);

  const fetchTrendingNews = async () => {
    setNewsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('trending-news');
      if (error) throw error;
      if (data?.success && data.data) {
        setTrendingNews(data.data);
      }
    } catch (err) {
      console.error('Failed to fetch trending news:', err);
    } finally {
      setNewsLoading(false);
    }
  };

  const fetchWorkspaces = async () => {
    const { data, error } = await supabase
      .from("workspaces")
      .select("*, sources(count)")
      .order("created_at", { ascending: false });

    if (error) {
      toast.error("Failed to load workspaces");
    } else {
      const mapped = (data || []).map((w: any) => ({
        ...w,
        source_count: w.sources?.[0]?.count ?? 0,
      }));
      setWorkspaces(mapped);
    }
    setLoading(false);
  };

  const handleCreateWorkspace = async () => {
    const { data, error } = await supabase
      .from("workspaces")
      .insert({ title: "Untitled Workspace", user_id: user!.id })
      .select()
      .single();

    if (error) {
      toast.error("Failed to create workspace");
      return;
    }
    navigate(`/workspace/${data.id}`);
  };

  const handleCreateFromNews = async (newsItem: NewsItem) => {
    setCreatingFromNews(newsItem.title);
    try {
      // Create workspace with news title
      const { data: ws, error: wsError } = await supabase
        .from("workspaces")
        .insert({ title: newsItem.title, user_id: user!.id, description: newsItem.description })
        .select()
        .single();

      if (wsError) throw wsError;

      // Add the news article as a source
      await supabase.from("sources").insert({
        workspace_id: ws.id,
        user_id: user!.id,
        name: newsItem.title,
        type: "link",
        url: newsItem.url,
        content: newsItem.description,
        metadata: {
          source: newsItem.source,
          image: newsItem.image,
          publishedAt: newsItem.publishedAt,
          category: newsItem.category,
        },
      });

      navigate(`/workspace/${ws.id}`);
    } catch (err) {
      toast.error("Failed to create workspace from news");
    } finally {
      setCreatingFromNews(null);
    }
  };

  const handleDeleteWorkspace = async () => {
    if (!deleteId) return;
    await supabase.from("sources").delete().eq("workspace_id", deleteId);
    await supabase.from("chat_messages").delete().eq("workspace_id", deleteId);
    await supabase.from("generated_outputs").delete().eq("workspace_id", deleteId);
    await supabase.from("notes").delete().eq("workspace_id", deleteId);

    const { error } = await supabase.from("workspaces").delete().eq("id", deleteId);
    if (error) {
      toast.error("Failed to delete workspace");
    } else {
      setWorkspaces((prev) => prev.filter((w) => w.id !== deleteId));
      toast.success("Workspace deleted");
    }
    setDeleteId(null);
  };

  const handleRenameWorkspace = async () => {
    if (!renameId || !renameValue.trim()) return;
    const { error } = await supabase.from("workspaces").update({ title: renameValue.trim() }).eq("id", renameId);
    if (error) {
      toast.error("Failed to rename workspace");
    } else {
      setWorkspaces((prev) => prev.map((w) => w.id === renameId ? { ...w, title: renameValue.trim() } : w));
      toast.success("Workspace renamed");
    }
    setRenameId(null);
    setRenameValue("");
  };

  const handleSignOut = async () => {
    await signOut();
    navigate("/");
    toast.success("Signed out");
  };

  const sortedWorkspaces = [...workspaces].sort((a, b) => {
    if (sortBy === "alpha") return a.title.localeCompare(b.title);
    if (sortBy === "sources") return (b.source_count || 0) - (a.source_count || 0);
    return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
  });

  const filteredWorkspaces = sortedWorkspaces.filter((w) =>
    w.title.toLowerCase().includes(search.toLowerCase())
  );

  const displayName = user?.user_metadata?.full_name || user?.email?.split("@")[0] || "User";
  const initials = displayName.slice(0, 2).toUpperCase();

  return (
    <div className="min-h-screen bg-gradient-hero dark" style={{ colorScheme: 'dark' }}>
      {/* Header */}
      <header className="border-b border-border/30 bg-card/20 backdrop-blur-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
              <Zap className="h-4.5 w-4.5 text-primary" />
            </div>
            <span className="font-display text-lg font-bold text-foreground">StudySync AI</span>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="hidden sm:flex gap-1.5 text-muted-foreground border-border/50 bg-transparent hover:bg-card/40">
              <Settings className="h-3.5 w-3.5" /> Settings
            </Button>
            <div className="h-5 w-px bg-border/30 hidden sm:block" />
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-2 rounded-full hover:ring-2 hover:ring-primary/20 transition-all">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-primary/10 text-primary text-xs font-semibold">
                      {initials}
                    </AvatarFallback>
                  </Avatar>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem className="text-muted-foreground text-xs" disabled>
                  {user?.email}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleSignOut}>
                  <LogOut className="h-4 w-4 mr-2" /> Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Tabs + Controls Row */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div className="flex items-center gap-1 bg-card/20 rounded-full p-1 border border-border/30">
            {([
              { key: "all" as Tab, label: "All" },
              { key: "my" as Tab, label: "My notebooks" },
              { key: "featured" as Tab, label: "Trending" },
            ]).map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${
                  activeTab === tab.key
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center border border-border/30 rounded-lg overflow-hidden bg-card/20">
              <button
                onClick={() => setViewMode("grid")}
                className={`p-2 transition-colors ${viewMode === "grid" ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground"}`}
              >
                <LayoutGrid className="h-4 w-4" />
              </button>
              <button
                onClick={() => setViewMode("list")}
                className={`p-2 transition-colors ${viewMode === "list" ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground"}`}
              >
                <List className="h-4 w-4" />
              </button>
            </div>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="gap-1.5 border-border/30 bg-transparent hover:bg-card/40">
                  {sortBy === "recent" ? "Most recent" : sortBy === "alpha" ? "A–Z" : "Most sources"}
                  <ChevronDown className="h-3.5 w-3.5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setSortBy("recent")}>Most recent</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSortBy("alpha")}>A–Z</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSortBy("sources")}>Most sources</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button onClick={handleCreateWorkspace} className="gap-1.5">
              <Plus className="h-4 w-4" /> Create new
            </Button>
          </div>
        </div>

        {/* Search */}
        <div className="relative max-w-md mb-8">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search notebooks..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 text-foreground bg-card/30 border-border/30"
          />
        </div>

        {/* Trending / Featured Section */}
        {(activeTab === "all" || activeTab === "featured") && (
          <motion.section
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-10"
          >
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="h-5 w-5 text-primary" />
              <h2 className="font-display text-lg font-bold text-foreground">Trending Study Packs</h2>
              <span className="text-xs text-muted-foreground bg-primary/10 px-2 py-0.5 rounded-full">AI-curated</span>
              <button
                onClick={fetchTrendingNews}
                className="ml-2 text-xs text-muted-foreground hover:text-primary transition-colors"
                disabled={newsLoading}
              >
                {newsLoading ? <Loader2 className="h-3 w-3 animate-spin" /> : "Refresh"}
              </button>
            </div>

            <div className="flex gap-4 overflow-x-auto pb-4 -mx-2 px-2 scrollbar-hide">
              {newsLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="flex-shrink-0 w-72 h-48 rounded-2xl overflow-hidden border border-border/20">
                    <Skeleton className="w-full h-full bg-card/30" />
                  </div>
                ))
              ) : trendingNews.length === 0 ? (
                <div className="w-full text-center py-10 text-muted-foreground text-sm">
                  No trending news available right now.
                </div>
              ) : (
                trendingNews.map((news, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: i * 0.05 }}
                    onClick={() => handleCreateFromNews(news)}
                    className="flex-shrink-0 w-72 h-48 rounded-2xl border border-border/20 cursor-pointer hover:scale-[1.02] hover:border-primary/30 transition-all group relative overflow-hidden"
                  >
                    {/* Background image or gradient fallback */}
                    {news.image ? (
                      <img
                        src={news.image}
                        alt={news.title}
                        className="absolute inset-0 w-full h-full object-cover opacity-40 group-hover:opacity-50 transition-opacity"
                        onError={(e) => {
                          (e.target as HTMLImageElement).style.display = 'none';
                        }}
                      />
                    ) : null}
                    <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
                    
                    {/* Loading overlay */}
                    {creatingFromNews === news.title && (
                      <div className="absolute inset-0 bg-background/80 flex items-center justify-center z-10">
                        <Loader2 className="h-6 w-6 animate-spin text-primary" />
                      </div>
                    )}

                    {/* Content */}
                    <div className="relative z-[1] h-full flex flex-col justify-end p-4">
                      <div className="flex items-center gap-1.5 mb-2">
                        <span className="text-[10px] font-semibold uppercase tracking-wider text-primary bg-primary/10 px-2 py-0.5 rounded-full">
                          {news.category}
                        </span>
                        <span className="text-[10px] text-muted-foreground">{news.source}</span>
                      </div>
                      <h3 className="font-display font-semibold text-foreground text-sm leading-tight line-clamp-2 mb-1.5">
                        {news.title}
                      </h3>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span>{new Date(news.publishedAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</span>
                        <ExternalLink className="h-3 w-3 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                    </div>
                  </motion.div>
                ))
              )}
            </div>
          </motion.section>
        )}

        {/* Recent / My Notebooks */}
        {(activeTab === "all" || activeTab === "my") && (
          <section>
            <h2 className="font-display text-lg font-bold text-foreground mb-4">
              {activeTab === "my" ? "My notebooks" : "Recent notebooks"}
            </h2>

            {loading ? (
              <div className="text-center py-20 text-muted-foreground">Loading...</div>
            ) : filteredWorkspaces.length === 0 && !search ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-20"
              >
                <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10">
                  <Plus className="h-8 w-8 text-primary" />
                </div>
                <h3 className="font-display text-lg font-semibold text-foreground mb-2">No notebooks yet</h3>
                <p className="text-muted-foreground text-sm mb-6">
                  Create your first notebook to start learning with AI.
                </p>
                <Button onClick={handleCreateWorkspace} className="gap-1.5">
                  <Plus className="h-4 w-4" /> Create Notebook
                </Button>
              </motion.div>
            ) : (
              <AnimatePresence mode="wait">
                {viewMode === "grid" ? (
                  <motion.div
                    key="grid"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4"
                  >
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      onClick={handleCreateWorkspace}
                      className="rounded-2xl border-2 border-dashed border-border/30 bg-card/10 hover:border-primary/40 hover:bg-primary/5 transition-all cursor-pointer flex flex-col items-center justify-center min-h-[180px] group"
                    >
                      <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10 group-hover:bg-primary/20 transition-colors mb-3">
                        <Plus className="h-6 w-6 text-primary" />
                      </div>
                      <span className="text-sm font-medium text-muted-foreground group-hover:text-foreground transition-colors">Create new notebook</span>
                    </motion.div>

                    {filteredWorkspaces.map((ws, i) => (
                      <motion.div
                        key={ws.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.03 }}
                        onClick={() => navigate(`/workspace/${ws.id}`)}
                        className="group cursor-pointer rounded-2xl border border-border/30 bg-card/30 hover:border-primary/30 hover:shadow-glow transition-all duration-300 overflow-hidden"
                      >
                        <div className={`h-20 bg-gradient-to-br ${getWorkspaceGradient(ws.title)} flex items-center justify-center relative`}>
                          <span className="text-4xl">{getWorkspaceEmoji(ws.title)}</span>
                          <div className="absolute top-2 right-2">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <button
                                  onClick={(e) => e.stopPropagation()}
                                  className="flex h-7 w-7 items-center justify-center rounded-full bg-background/60 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity hover:bg-background/80"
                                >
                                  <MoreVertical className="h-3.5 w-3.5 text-foreground" />
                                </button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
                                <DropdownMenuItem onClick={() => { setRenameId(ws.id); setRenameValue(ws.title); }}>
                                  <Pencil className="h-4 w-4 mr-2" /> Rename
                                </DropdownMenuItem>
                                <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => setDeleteId(ws.id)}>
                                  <Trash2 className="h-4 w-4 mr-2" /> Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </div>
                        <div className="p-4">
                          <h3 className="font-display font-semibold text-white text-sm leading-tight line-clamp-2 mb-2">{ws.title}</h3>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <span>{new Date(ws.created_at).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</span>
                            <span>·</span>
                            <span>{ws.source_count || 0} source{(ws.source_count || 0) !== 1 ? "s" : ""}</span>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </motion.div>
                ) : (
                  <motion.div
                    key="list"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="space-y-2"
                  >
                    {filteredWorkspaces.map((ws, i) => (
                      <motion.div
                        key={ws.id}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.03 }}
                        onClick={() => navigate(`/workspace/${ws.id}`)}
                        className="group flex items-center gap-4 rounded-xl border border-border/30 bg-card/30 px-5 py-3.5 cursor-pointer hover:border-primary/30 hover:shadow-glow transition-all duration-300"
                      >
                        <span className="text-2xl flex-shrink-0">{getWorkspaceEmoji(ws.title)}</span>
                        <div className="flex-1 min-w-0">
                          <h3 className="font-display font-semibold text-white text-sm truncate">{ws.title}</h3>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
                            <Clock className="h-3 w-3" />
                            <span>{new Date(ws.created_at).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</span>
                            <span>·</span>
                            <span>{ws.source_count || 0} source{(ws.source_count || 0) !== 1 ? "s" : ""}</span>
                          </div>
                        </div>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <button
                              onClick={(e) => e.stopPropagation()}
                              className="flex h-8 w-8 items-center justify-center rounded-lg opacity-0 group-hover:opacity-100 transition-opacity hover:bg-muted/20"
                            >
                              <MoreVertical className="h-4 w-4 text-muted-foreground" />
                            </button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
                            <DropdownMenuItem onClick={() => { setRenameId(ws.id); setRenameValue(ws.title); }}>
                              <Pencil className="h-4 w-4 mr-2" /> Rename
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => setDeleteId(ws.id)}>
                              <Trash2 className="h-4 w-4 mr-2" /> Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </motion.div>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            )}

            {search && filteredWorkspaces.length === 0 && (
              <div className="text-center py-16">
                <Search className="h-8 w-8 mx-auto mb-3 text-muted-foreground/40" />
                <p className="text-muted-foreground text-sm">No notebooks match "{search}"</p>
              </div>
            )}
          </section>
        )}
      </main>

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete notebook?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the notebook and all its sources, notes, and generated outputs. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteWorkspace} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Rename dialog */}
      <AlertDialog open={!!renameId} onOpenChange={(open) => !open && setRenameId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Rename notebook</AlertDialogTitle>
          </AlertDialogHeader>
          <Input
            value={renameValue}
            onChange={(e) => setRenameValue(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleRenameWorkspace()}
            className="text-foreground"
            placeholder="Notebook name..."
            autoFocus
          />
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleRenameWorkspace} disabled={!renameValue.trim()}>
              Save
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Dashboard;
