import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Brain, FileText, Mic, BarChart3, Layers, BookOpen,
  HelpCircle, Map, Video, Table2, ArrowRight, Sparkles,
  Zap, GraduationCap, Target, Check
} from "lucide-react";

const features = [
  { icon: Brain, title: "AI Chat", desc: "Ask questions about your sources with cited answers" },
  { icon: BookOpen, title: "Flashcards", desc: "Auto-generated spaced repetition cards" },
  { icon: HelpCircle, title: "Quizzes", desc: "Multi-level interactive assessments" },
  { icon: Map, title: "Mind Maps", desc: "Visual knowledge graphs" },
  { icon: Mic, title: "AI Podcast", desc: "Two-host conversational summaries" },
  { icon: Layers, title: "Slide Decks", desc: "Presentation-ready slides" },
  { icon: Video, title: "Video Overview", desc: "AI explainer videos" },
  { icon: FileText, title: "Reports", desc: "Structured research reports" },
  { icon: BarChart3, title: "Infographics", desc: "Charts & visual data" },
  { icon: Table2, title: "Data Tables", desc: "Structured data extraction" },
];

const killerFeatures = [
  {
    icon: GraduationCap,
    title: "Learn Mode",
    desc: "Auto-converts sources into structured courses with modules, lessons, quizzes, and a final exam. Your AI tutor teaches step-by-step.",
  },
  {
    icon: Target,
    title: "Exam Simulator",
    desc: "Generate practice exams, mock tests, and timed quizzes from your study materials. Get instant grading and performance analysis.",
  },
];

const pricingPlans = [
  {
    name: "Free",
    price: "$0",
    period: "forever",
    features: ["3 workspaces", "10 sources per workspace", "AI Chat", "Flashcards & Quizzes", "Basic exports"],
    cta: "Start Free",
    highlight: false,
  },
  {
    name: "Pro",
    price: "$19",
    period: "/month",
    features: ["Unlimited workspaces", "Unlimited sources", "All 10 generators", "Learn Mode & Exam Simulator", "Priority AI", "PDF & PPT exports"],
    cta: "Start Pro Trial",
    highlight: true,
  },
];

const Landing = () => {
  return (
    <div className="min-h-screen bg-gradient-hero dark text-foreground" style={{ colorScheme: 'dark' }}>
      {/* Nav */}
      <nav className="flex items-center justify-between px-6 py-4 max-w-7xl mx-auto">
        <div className="flex items-center gap-2">
          <Zap className="h-6 w-6 text-primary" />
          <span className="font-display text-xl font-bold text-foreground">StudySync AI</span>
        </div>
        <div className="flex items-center gap-3">
          <Link to="/auth">
            <Button variant="ghost" className="text-muted-foreground">Log in</Button>
          </Link>
          <Link to="/auth?tab=signup">
            <Button variant="hero" size="lg">
              Get Started <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="max-w-7xl mx-auto px-6 pt-20 pb-32 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className="inline-flex items-center gap-2 rounded-full border border-border/50 bg-card/30 px-4 py-1.5 text-sm text-muted-foreground mb-8">
            <Sparkles className="h-3.5 w-3.5 text-primary" />
            AI-Powered Research & Study Platform
          </div>
          <h1 className="font-display text-5xl md:text-7xl font-bold tracking-tight leading-tight">
            Transform sources into
            <br />
            <span className="text-gradient-primary">structured learning</span>
          </h1>
          <p className="mt-6 text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Upload PDFs, links, and videos. Get AI-powered flashcards, quizzes,
            mind maps, courses, exams, and more — all from your sources.
          </p>
          <div className="mt-10 flex justify-center gap-4">
            <Link to="/auth?tab=signup">
              <Button variant="hero" size="lg" className="text-base px-8 py-6">
                Start Learning <ArrowRight className="h-5 w-5" />
              </Button>
            </Link>
            <Link to="/auth">
              <Button variant="outline" size="lg" className="text-base px-8 py-6 border-border/50 text-foreground hover:bg-card/50">
                Try Now
              </Button>
            </Link>
          </div>
        </motion.div>
      </section>

      {/* Features Grid */}
      <section className="max-w-7xl mx-auto px-6 pb-24">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-3xl md:text-4xl font-bold">
            10 powerful tools, <span className="text-gradient-accent">one platform</span>
          </h2>
          <p className="mt-4 text-muted-foreground text-lg">
            Every output you need, generated from your uploaded sources.
          </p>
        </motion.div>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: i * 0.05 }}
              viewport={{ once: true }}
              className="group relative rounded-xl border border-border/50 bg-card/50 p-5 text-center hover:border-primary/30 hover:shadow-glow transition-all duration-300"
            >
              <div className="mx-auto mb-3 flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary group-hover:bg-primary/20 transition-colors">
                <f.icon className="h-5 w-5" />
              </div>
              <h3 className="font-display font-semibold text-sm">{f.title}</h3>
              <p className="mt-1 text-xs text-muted-foreground">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Killer Features */}
      <section className="max-w-7xl mx-auto px-6 pb-24">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-3xl md:text-4xl font-bold">
            Killer features that <span className="text-gradient-primary">set us apart</span>
          </h2>
        </motion.div>
        <div className="grid md:grid-cols-2 gap-6">
          {killerFeatures.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              viewport={{ once: true }}
              className="rounded-2xl border border-primary/20 bg-card/50 p-8 hover:shadow-glow transition-all duration-300"
            >
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <f.icon className="h-6 w-6" />
              </div>
              <h3 className="font-display text-xl font-bold mb-2">{f.title}</h3>
              <p className="text-muted-foreground">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section className="max-w-4xl mx-auto px-6 pb-32">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-3xl md:text-4xl font-bold">
            Simple <span className="text-gradient-accent">pricing</span>
          </h2>
          <p className="mt-4 text-muted-foreground text-lg">Start free, upgrade when you need more.</p>
        </motion.div>
        <div className="grid md:grid-cols-2 gap-6">
          {pricingPlans.map((plan, i) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              viewport={{ once: true }}
              className={`rounded-2xl border p-8 ${plan.highlight ? "border-primary/40 bg-primary/5 shadow-glow" : "border-border/50 bg-card/50"}`}
            >
              <h3 className="font-display text-lg font-bold">{plan.name}</h3>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="font-display text-4xl font-bold">{plan.price}</span>
                <span className="text-muted-foreground text-sm">{plan.period}</span>
              </div>
              <ul className="mt-6 space-y-3">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-sm">
                    <Check className="h-4 w-4 text-primary flex-shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
              <Link to="/auth?tab=signup" className="block mt-8">
                <Button variant={plan.highlight ? "hero" : "outline"} className="w-full">
                  {plan.cta}
                </Button>
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/30 py-8 text-center text-sm text-muted-foreground">
        <p>© 2026 StudySync AI — Built with SheBuild on Lovable</p>
      </footer>
    </div>
  );
};

export default Landing;
