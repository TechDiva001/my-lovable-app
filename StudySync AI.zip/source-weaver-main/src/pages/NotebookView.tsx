import { useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowLeft, Plus, Upload, Link as LinkIcon, Youtube, FileText,
  Brain, BookOpen, HelpCircle, Map, Mic, Layers, Video,
  BarChart3, Table2, Sparkles, Send, X, MessageSquare
} from "lucide-react";

type Source = {
  id: string;
  type: "pdf" | "link" | "youtube";
  name: string;
  url?: string;
};

const outputTools = [
  { id: "chat", icon: MessageSquare, label: "AI Chat", color: "text-primary" },
  { id: "flashcards", icon: BookOpen, label: "Flashcards", color: "text-emerald-500" },
  { id: "quiz", icon: HelpCircle, label: "Quiz", color: "text-violet-500" },
  { id: "mindmap", icon: Map, label: "Mind Map", color: "text-blue-500" },
  { id: "audio", icon: Mic, label: "Audio Overview", color: "text-amber-500" },
  { id: "slides", icon: Layers, label: "Slide Deck", color: "text-rose-500" },
  { id: "video", icon: Video, label: "Video Overview", color: "text-cyan-500" },
  { id: "report", icon: FileText, label: "Report", color: "text-orange-500" },
  { id: "infographic", icon: BarChart3, label: "Infographic", color: "text-teal-500" },
  { id: "datatable", icon: Table2, label: "Data Table", color: "text-indigo-500" },
];

const NotebookView = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [title, setTitle] = useState("Untitled Notebook");
  const [sources, setSources] = useState<Source[]>([]);
  const [activeTab, setActiveTab] = useState<string | null>(null);
  const [showAddSource, setShowAddSource] = useState(false);
  const [linkInput, setLinkInput] = useState("");
  const [chatMessages, setChatMessages] = useState<{ role: string; content: string }[]>([]);
  const [chatInput, setChatInput] = useState("");

  const addSource = (type: Source["type"], name: string, url?: string) => {
    setSources([...sources, { id: crypto.randomUUID(), type, name, url }]);
    setShowAddSource(false);
    setLinkInput("");
  };

  const removeSource = (sid: string) => {
    setSources(sources.filter((s) => s.id !== sid));
  };

  const handleAddLink = () => {
    if (!linkInput.trim()) return;
    const isYouTube = linkInput.includes("youtube.com") || linkInput.includes("youtu.be");
    addSource(isYouTube ? "youtube" : "link", linkInput, linkInput);
  };

  const getSourceIcon = (type: Source["type"]) => {
    switch (type) {
      case "pdf": return <FileText className="h-4 w-4" />;
      case "youtube": return <Youtube className="h-4 w-4 text-red-500" />;
      case "link": return <LinkIcon className="h-4 w-4 text-blue-500" />;
    }
  };

  return (
    <div className="min-h-screen bg-background flex">
      {/* Left Sidebar - Sources */}
      <div className="w-80 border-r border-border/50 bg-card/30 flex flex-col">
        <div className="p-4 border-b border-border/50">
          <Link to="/dashboard" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-3">
            <ArrowLeft className="h-3.5 w-3.5" /> Dashboard
          </Link>
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full bg-transparent font-display text-lg font-bold outline-none placeholder:text-muted-foreground"
            placeholder="Notebook title..."
          />
        </div>

        {/* Sources */}
        <div className="flex-1 overflow-y-auto p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Sources</h3>
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setShowAddSource(!showAddSource)}>
              <Plus className="h-4 w-4" />
            </Button>
          </div>

          <AnimatePresence>
            {showAddSource && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="mb-4 space-y-2 overflow-hidden"
              >
                <div className="flex gap-2">
                  <Input
                    placeholder="Paste a URL or YouTube link..."
                    value={linkInput}
                    onChange={(e) => setLinkInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleAddLink()}
                    className="text-sm"
                  />
                  <Button size="sm" onClick={handleAddLink} disabled={!linkInput.trim()}>
                    <Plus className="h-3.5 w-3.5" />
                  </Button>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full"
                  onClick={() => addSource("pdf", "sample-document.pdf")}
                >
                  <Upload className="h-3.5 w-3.5 mr-1.5" /> Upload PDF
                </Button>
              </motion.div>
            )}
          </AnimatePresence>

          {sources.length === 0 ? (
            <div className="text-center py-10">
              <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                <Upload className="h-5 w-5 text-primary" />
              </div>
              <p className="text-sm text-muted-foreground">
                Add sources to get started
              </p>
              <Button
                variant="outline"
                size="sm"
                className="mt-3"
                onClick={() => setShowAddSource(true)}
              >
                <Plus className="h-3.5 w-3.5 mr-1" /> Add Source
              </Button>
            </div>
          ) : (
            <div className="space-y-2">
              {sources.map((s) => (
                <div
                  key={s.id}
                  className="flex items-center gap-2 rounded-lg border border-border/50 bg-card/50 p-2.5 group"
                >
                  {getSourceIcon(s.type)}
                  <span className="flex-1 text-sm truncate">{s.name}</span>
                  <button
                    onClick={() => removeSource(s.id)}
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="h-3.5 w-3.5 text-muted-foreground hover:text-destructive" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Tools Strip */}
        <div className="border-b border-border/50 bg-card/30 px-6 py-3 overflow-x-auto">
          <div className="flex gap-2">
            {outputTools.map((tool) => (
              <Button
                key={tool.id}
                variant={activeTab === tool.id ? "default" : "outline"}
                size="sm"
                onClick={() => setActiveTab(activeTab === tool.id ? null : tool.id)}
                className="whitespace-nowrap"
              >
                <tool.icon className={`h-3.5 w-3.5 mr-1.5 ${activeTab !== tool.id ? tool.color : ""}`} />
                {tool.label}
              </Button>
            ))}
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-6">
          {!activeTab ? (
            <div className="h-full flex items-center justify-center">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center max-w-md"
              >
                <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10">
                  <Sparkles className="h-8 w-8 text-primary" />
                </div>
                <h2 className="font-display text-xl font-bold mb-2">
                  Ready to generate
                </h2>
                <p className="text-muted-foreground text-sm">
                  {sources.length === 0
                    ? "Add some sources first, then select a tool to generate content."
                    : "Select a tool above to generate content from your sources."}
                </p>
              </motion.div>
            </div>
          ) : activeTab === "chat" ? (
            <div className="h-full flex flex-col">
              <div className="flex-1 overflow-y-auto space-y-4 pb-4">
                {chatMessages.length === 0 && (
                  <div className="text-center py-16 text-muted-foreground text-sm">
                    <Brain className="h-8 w-8 mx-auto mb-3 text-primary/40" />
                    Ask anything about your sources...
                  </div>
                )}
                {chatMessages.map((msg, i) => (
                  <div
                    key={i}
                    className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-lg rounded-xl px-4 py-2.5 text-sm ${
                        msg.role === "user"
                          ? "bg-primary text-primary-foreground"
                          : "bg-card border border-border/50"
                      }`}
                    >
                      {msg.content}
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex gap-2 pt-2 border-t border-border/50">
                <Input
                  placeholder="Ask about your sources..."
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && chatInput.trim()) {
                      setChatMessages([...chatMessages, { role: "user", content: chatInput }]);
                      setChatInput("");
                    }
                  }}
                />
                <Button
                  size="icon"
                  disabled={!chatInput.trim()}
                  onClick={() => {
                    if (chatInput.trim()) {
                      setChatMessages([...chatMessages, { role: "user", content: chatInput }]);
                      setChatInput("");
                    }
                  }}
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ) : (
            <ToolPlaceholder
              tool={outputTools.find((t) => t.id === activeTab)!}
              hasSources={sources.length > 0}
            />
          )}
        </div>
      </div>
    </div>
  );
};

const ToolPlaceholder = ({
  tool,
  hasSources,
}: {
  tool: (typeof outputTools)[0];
  hasSources: boolean;
}) => (
  <motion.div
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    className="h-full flex items-center justify-center"
  >
    <div className="text-center max-w-md">
      <div className={`mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-card border border-border/50`}>
        <tool.icon className={`h-8 w-8 ${tool.color}`} />
      </div>
      <h2 className="font-display text-xl font-bold mb-2">{tool.label}</h2>
      <p className="text-muted-foreground text-sm mb-6">
        {hasSources
          ? `Generate ${tool.label.toLowerCase()} from your uploaded sources.`
          : `Add sources first to generate ${tool.label.toLowerCase()}.`}
      </p>
      <Button variant="hero" disabled={!hasSources}>
        <Sparkles className="h-4 w-4" /> Generate {tool.label}
      </Button>
    </div>
  </motion.div>
);

export default NotebookView;
