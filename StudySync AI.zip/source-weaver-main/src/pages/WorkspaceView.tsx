import { useState, useEffect, useRef, useCallback } from "react";
import { useParams, Link } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Checkbox } from "@/components/ui/checkbox";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from "@/components/ui/resizable";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import ReactMarkdown from "react-markdown";
import {
  ArrowLeft, Plus, Upload, Link as LinkIcon, Youtube, FileText,
  Brain, BookOpen, HelpCircle, Map, Layers,
  BarChart3, Table2, Send, X,
  Sparkles, StickyNote, Zap, PanelRightClose, PanelRightOpen,
  PanelLeftClose, PanelLeftOpen,
  File, Image, Music, Video, CheckSquare, Loader2, RefreshCw, FileSpreadsheet, Presentation,
  Volume2, Eye, GraduationCap
} from "lucide-react";
import FlashcardGenerator from "@/components/generators/FlashcardGenerator";
import QuizGenerator from "@/components/generators/QuizGenerator";
import MindMapGenerator from "@/components/generators/MindMapGenerator";
import SlideGenerator from "@/components/generators/SlideGenerator";
import ReportGenerator from "@/components/generators/ReportGenerator";
import InfographicGenerator from "@/components/generators/InfographicGenerator";
import DataTableGenerator from "@/components/generators/DataTableGenerator";
import AIAudioGenerator from "@/components/generators/AIAudioGenerator";
import AIVideoGenerator from "@/components/generators/AIVideoGenerator";
import AIVisualsGenerator from "@/components/generators/AIVisualsGenerator";
import AITutorGenerator from "@/components/generators/AITutorGenerator";

type Source = {
  id: string;
  type: string;
  name: string;
  url?: string | null;
};

type UploadingFile = {
  name: string;
  progress: number;
  done: boolean;
};

type ChatMessage = {
  role: "user" | "assistant";
  content: string;
};

type GeneratedOutput = {
  id: string;
  type: string;
  title: string;
  content: any;
  created_at: string;
};

const ACCEPTED_FILE_TYPES = ".pdf,.doc,.docx,.pptx,.ppt,.txt,.md,.csv,.json,.xml,.jpg,.jpeg,.png,.gif,.webp,.mp3,.wav,.m4a,.mp4,.webm";
const CHAT_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/chat`;

const studioTools = [
  { id: "ai-audio", icon: Volume2, label: "AI Audio", color: "text-primary" },
  { id: "ai-video", icon: Video, label: "AI Video", color: "text-primary" },
  { id: "ai-visuals", icon: Eye, label: "AI Visuals", color: "text-primary" },
  { id: "ai-tutor", icon: GraduationCap, label: "AI Tutor", color: "text-primary" },
  { id: "flashcards", icon: BookOpen, label: "Flashcards", color: "text-primary" },
  { id: "quiz", icon: HelpCircle, label: "Quiz Generator", color: "text-primary" },
  { id: "slides", icon: Layers, label: "Slide Deck", color: "text-primary" },
  { id: "mindmap", icon: Map, label: "Mind Map", color: "text-primary" },
  { id: "report", icon: FileText, label: "Report Generator", color: "text-primary" },
  { id: "infographic", icon: BarChart3, label: "Infographic", color: "text-primary" },
  { id: "datatable", icon: Table2, label: "Data Table", color: "text-primary" },
];

const MESSAGES_PER_PAGE = 30;

const WorkspaceView = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const [title, setTitle] = useState("Untitled Workspace");
  const [sources, setSources] = useState<Source[]>([]);
  const [selectedSourceIds, setSelectedSourceIds] = useState<Set<string>>(new Set());
  const [showAddSource, setShowAddSource] = useState(false);
  const [linkInput, setLinkInput] = useState("");
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [studioOpen, setStudioOpen] = useState(false);
  const [sourcesOpen, setSourcesOpen] = useState(true);
  const [activeTool, setActiveTool] = useState<string | null>(null);
  const [leftSidebarTab, setLeftSidebarTab] = useState<"sources" | "outputs" | "notes">("sources");
  const [notes, setNotes] = useState("");
  const [uploadingFiles, setUploadingFiles] = useState<UploadingFile[]>([]);
  const [isDragOver, setIsDragOver] = useState(false);
  const [hasMoreMessages, setHasMoreMessages] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [oldestMessageDate, setOldestMessageDate] = useState<string | null>(null);
  const [initialLoadDone, setInitialLoadDone] = useState(false);
  const [outputs, setOutputs] = useState<GeneratedOutput[]>([]);
  const [outputFilter, setOutputFilter] = useState<string>("all");
  const chatEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const overviewSentRef = useRef(false);

  useEffect(() => {
    if (id) { 
      fetchWorkspace(); 
      fetchSources(); 
      loadChatHistory();
      fetchOutputs();
    }
  }, [id]);

  useEffect(() => {
    if (initialLoadDone) {
      chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [chatMessages, initialLoadDone]);

  const saveChatMessage = async (role: string, content: string) => {
    if (!user || !id || !content.trim()) return;
    await supabase.from("chat_messages").insert({
      workspace_id: id,
      user_id: user.id,
      role,
      content,
    });
  };

  const loadChatHistory = async () => {
    if (!id) return;
    const { data, count } = await supabase
      .from("chat_messages")
      .select("*", { count: "exact" })
      .eq("workspace_id", id)
      .order("created_at", { ascending: false })
      .limit(MESSAGES_PER_PAGE);

    if (data && data.length > 0) {
      const messages: ChatMessage[] = data.reverse().map((m) => ({
        role: m.role as "user" | "assistant",
        content: m.content,
      }));
      setChatMessages(messages);
      setOldestMessageDate(data[0].created_at);
      setHasMoreMessages((count || 0) > MESSAGES_PER_PAGE);
      overviewSentRef.current = true; // don't re-trigger overview if we have history
    }
    setInitialLoadDone(true);
  };

  const loadMoreMessages = async () => {
    if (!id || !oldestMessageDate || loadingMore) return;
    setLoadingMore(true);
    const container = chatContainerRef.current;
    const prevScrollHeight = container?.scrollHeight || 0;

    const { data } = await supabase
      .from("chat_messages")
      .select("*")
      .eq("workspace_id", id)
      .lt("created_at", oldestMessageDate)
      .order("created_at", { ascending: false })
      .limit(MESSAGES_PER_PAGE);

    if (data && data.length > 0) {
      const older: ChatMessage[] = data.reverse().map((m) => ({
        role: m.role as "user" | "assistant",
        content: m.content,
      }));
      setChatMessages((prev) => [...older, ...prev]);
      setOldestMessageDate(data[0].created_at);
      setHasMoreMessages(data.length === MESSAGES_PER_PAGE);
      // Preserve scroll position
      requestAnimationFrame(() => {
        if (container) {
          container.scrollTop = container.scrollHeight - prevScrollHeight;
        }
      });
    } else {
      setHasMoreMessages(false);
    }
    setLoadingMore(false);
  };

  const fetchWorkspace = async () => {
    const { data } = await supabase.from("workspaces").select("*").eq("id", id).single();
    if (data) setTitle(data.title);
  };

  const fetchSources = async () => {
    const { data } = await supabase.from("sources").select("*").eq("workspace_id", id).order("created_at", { ascending: false });
    if (data) {
      setSources(data);
      setSelectedSourceIds(new Set(data.map((s: Source) => s.id)));
    }
  };

  const updateTitle = async (newTitle: string) => {
    setTitle(newTitle);
    await supabase.from("workspaces").update({ title: newTitle }).eq("id", id);
  };

  const addSource = async (type: string, name: string, url?: string) => {
    const { data, error } = await supabase
      .from("sources")
      .insert({ workspace_id: id!, user_id: user!.id, type, name, url })
      .select()
      .single();
    if (error) { toast.error("Failed to add source"); return null; }
    return data;
  };

  const fetchOutputs = async () => {
    if (!id) return;
    const { data } = await supabase
      .from("generated_outputs")
      .select("*")
      .eq("workspace_id", id)
      .order("created_at", { ascending: false });
    if (data) setOutputs(data);
  };

  const saveOutput = async (type: string, title: string, content: any) => {
    if (!user || !id) return;
    const { data, error } = await supabase
      .from("generated_outputs")
      .insert({
        workspace_id: id,
        user_id: user.id,
        type,
        title,
        content,
      })
      .select()
      .single();
    
    if (error) {
      toast.error("Failed to save output");
      return;
    }
    
    if (data) {
      setOutputs((prev) => [data, ...prev]);
      toast.success("Output saved!");
    }
  };

  const deleteOutput = async (outputId: string) => {
    const { error } = await supabase
      .from("generated_outputs")
      .delete()
      .eq("id", outputId);
    
    if (error) {
      toast.error("Failed to delete output");
      return;
    }
    
    setOutputs((prev) => prev.filter((o) => o.id !== outputId));
    toast.success("Output deleted");
  };

  const removeSource = async (sid: string) => {
    await supabase.from("sources").delete().eq("id", sid);
    setSources((prev) => prev.filter((s) => s.id !== sid));
    setSelectedSourceIds((prev) => {
      const next = new Set(prev);
      next.delete(sid);
      return next;
    });
  };

  const triggerOverview = useCallback(async (newSources: Source[]) => {
    if (overviewSentRef.current || newSources.length === 0) return;
    overviewSentRef.current = true;

    const sourceNames = newSources.map((s) => `- ${s.name} (${s.type})`).join("\n");
    const userMessage: ChatMessage = {
      role: "user",
      content: `I've uploaded the following sources:\n${sourceNames}\n\nPlease give me an overview of what these sources are about and highlight the key themes.`,
    };

    setChatMessages((prev) => [...prev, userMessage]);
    await saveChatMessage("user", userMessage.content);
    setIsStreaming(true);

    // Auto-name workspace from source filenames (use first source name without extension as title)
    const firstName = newSources[0]?.name || "";
    const baseName = firstName.replace(/\.[^/.]+$/, "").replace(/[-_]/g, " ").trim();
    if (baseName && title === "Untitled Workspace") {
      updateTitle(baseName);
    }

    try {
      const resp = await fetch(CHAT_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}` },
        body: JSON.stringify({ messages: [{ role: "user", content: userMessage.content }] }),
      });

      if (!resp.ok || !resp.body) {
        const errData = await resp.json().catch(() => ({}));
        toast.error(errData.error || "Failed to get AI response");
        setIsStreaming(false);
        return;
      }

      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let textBuffer = "";
      let fullContent = "";
      setChatMessages((prev) => [...prev, { role: "assistant", content: "" }]);

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        textBuffer += decoder.decode(value, { stream: true });
        let newlineIndex: number;
        while ((newlineIndex = textBuffer.indexOf("\n")) !== -1) {
          const line = textBuffer.slice(0, newlineIndex).trim();
          textBuffer = textBuffer.slice(newlineIndex + 1);
          if (!line.startsWith("data: ")) continue;
          const payload = line.slice(6);
          if (payload === "[DONE]") break;
          try {
            const parsed = JSON.parse(payload);
            const delta = parsed.choices?.[0]?.delta?.content;
            if (delta) {
              fullContent += delta;
              setChatMessages((prev) => {
                const updated = [...prev];
                updated[updated.length - 1] = { role: "assistant", content: fullContent };
                return updated;
              });
            }
          } catch {}
        }
      }

      // Save the assistant response
      if (fullContent) await saveChatMessage("assistant", fullContent);
    } catch { toast.error("Failed to connect to AI"); }
    setIsStreaming(false);
  }, [title]);

  // Trigger overview for existing sources when workspace loads with sources but no chat history
  useEffect(() => {
    if (initialLoadDone && sources.length > 0 && chatMessages.length === 0 && !overviewSentRef.current) {
      triggerOverview(sources);
    }
  }, [initialLoadDone, sources, chatMessages.length, triggerOverview]);

  const uploadFiles = async (files: FileList | File[]) => {
    if (!user || !id) return;
    const fileArray = Array.from(files);
    setUploadingFiles(fileArray.map((f) => ({ name: f.name, progress: 0, done: false })));
    const newSources: Source[] = [];

    for (let i = 0; i < fileArray.length; i++) {
      const file = fileArray[i];
      const ext = file.name.split(".").pop()?.toLowerCase() || "";
      const filePath = `${user.id}/${id}/${Date.now()}-${file.name}`;

      const progressInterval = setInterval(() => {
        setUploadingFiles((prev) => prev.map((f, idx) => idx === i && !f.done ? { ...f, progress: Math.min(f.progress + 15, 90) } : f));
      }, 200);

      const { error: uploadError } = await supabase.storage.from("workspace-sources").upload(filePath, file);
      clearInterval(progressInterval);

      if (uploadError) {
        toast.error(`Failed to upload ${file.name}`);
        setUploadingFiles((prev) => prev.map((f, idx) => (idx === i ? { ...f, progress: 0, done: true } : f)));
        continue;
      }

      setUploadingFiles((prev) => prev.map((f, idx) => (idx === i ? { ...f, progress: 100, done: true } : f)));

      let type = "text";
      if (["jpg", "jpeg", "png", "gif", "webp"].includes(ext)) type = "image";
      else if (["mp3", "wav", "m4a"].includes(ext)) type = "audio";
      else if (["mp4", "webm"].includes(ext)) type = "video";
      else if (ext === "pdf") type = "pdf";
      else if (["doc", "docx"].includes(ext)) type = "docx";
      else if (["ppt", "pptx"].includes(ext)) type = "pptx";

      const data = await addSource(type, file.name, filePath);
      if (data) newSources.push(data);
    }

    if (newSources.length > 0) {
      setSources((prev) => {
        const updated = [...newSources, ...prev];
        setSelectedSourceIds(new Set(updated.map((s) => s.id)));
        return updated;
      });
      toast.success(`${newSources.length} file${newSources.length > 1 ? "s" : ""} uploaded`);
      setTimeout(() => { triggerOverview([...newSources, ...sources]); }, 500);
    }
    setTimeout(() => setUploadingFiles([]), 1500);
  };

  const handleFileDrop = (e: React.DragEvent) => { e.preventDefault(); setIsDragOver(false); if (e.dataTransfer.files.length > 0) uploadFiles(e.dataTransfer.files); };
  const handleDragOver = (e: React.DragEvent) => { e.preventDefault(); setIsDragOver(true); };
  const handleDragLeave = (e: React.DragEvent) => { e.preventDefault(); setIsDragOver(false); };

  const handleAddLink = async () => {
    if (!linkInput.trim()) return;
    const isYouTube = linkInput.includes("youtube.com") || linkInput.includes("youtu.be");
    const data = await addSource(isYouTube ? "youtube" : "link", linkInput, linkInput);
    if (data) {
      const updated = [data, ...sources];
      setSources(updated);
      setSelectedSourceIds(new Set(updated.map((s) => s.id)));
      setShowAddSource(false);
      setLinkInput("");
      toast.success("Source added");
    }
  };

  const toggleSourceSelection = (sid: string) => {
    setSelectedSourceIds((prev) => { const next = new Set(prev); if (next.has(sid)) next.delete(sid); else next.add(sid); return next; });
  };

  const toggleSelectAll = () => {
    if (selectedSourceIds.size === sources.length) setSelectedSourceIds(new Set());
    else setSelectedSourceIds(new Set(sources.map((s) => s.id)));
  };

  const getSourceIcon = (type: string) => {
    switch (type) {
      case "pdf": return <FileText className="h-4 w-4" />;
      case "youtube": return <Youtube className="h-4 w-4 text-destructive" />;
      case "link": return <LinkIcon className="h-4 w-4 text-primary" />;
      case "image": return <Image className="h-4 w-4 text-primary" />;
      case "audio": return <Music className="h-4 w-4 text-primary" />;
      case "video": return <Video className="h-4 w-4 text-primary" />;
      default: return <File className="h-4 w-4" />;
    }
  };

  const handleToolClick = (toolId: string) => {
    if (activeTool === toolId) { setActiveTool(null); setStudioOpen(false); }
    else { setActiveTool(toolId); setStudioOpen(true); }
  };

  const sendMessage = async () => {
    if (!chatInput.trim() || isStreaming) return;
    const userMsg: ChatMessage = { role: "user", content: chatInput };
    const updatedMessages = [...chatMessages, userMsg];
    setChatMessages(updatedMessages);
    setChatInput("");
    setIsStreaming(true);

    // Save user message to DB
    await saveChatMessage("user", userMsg.content);

    // Build context from selected sources
    const selectedSources = sources.filter((s) => selectedSourceIds.has(s.id));
    const sourceContext = selectedSources.length > 0
      ? `\n\n[Context: The user has selected these sources to work with: ${selectedSources.map((s) => s.name).join(", ")}. Answer based on these sources.]`
      : "";

    try {
      const messagesForAI = updatedMessages.map((m, i) => ({
        role: m.role,
        content: i === updatedMessages.length - 1 && m.role === "user"
          ? m.content + sourceContext
          : m.content,
      }));

      const resp = await fetch(CHAT_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}` },
        body: JSON.stringify({ messages: messagesForAI }),
      });

      if (!resp.ok || !resp.body) {
        const errData = await resp.json().catch(() => ({}));
        toast.error(errData.error || "Failed to get AI response");
        setIsStreaming(false);
        return;
      }

      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let textBuffer = "";
      let fullContent = "";
      setChatMessages((prev) => [...prev, { role: "assistant", content: "" }]);

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        textBuffer += decoder.decode(value, { stream: true });
        let newlineIndex: number;
        while ((newlineIndex = textBuffer.indexOf("\n")) !== -1) {
          const line = textBuffer.slice(0, newlineIndex).trim();
          textBuffer = textBuffer.slice(newlineIndex + 1);
          if (!line.startsWith("data: ")) continue;
          const payload = line.slice(6);
          if (payload === "[DONE]") break;
          try {
            const parsed = JSON.parse(payload);
            const delta = parsed.choices?.[0]?.delta?.content;
            if (delta) {
              fullContent += delta;
              setChatMessages((prev) => {
                const updated = [...prev];
                updated[updated.length - 1] = { role: "assistant", content: fullContent };
                return updated;
              });
            }
          } catch {}
        }
      }

      // Save assistant response to DB
      if (fullContent) await saveChatMessage("assistant", fullContent);
    } catch { toast.error("Failed to connect to AI"); }
    setIsStreaming(false);
  };

  const renderStudioContent = () => {
    const selectedSources = sources.filter((s) => selectedSourceIds.has(s.id));
    const hasSources = selectedSources.length > 0;
    switch (activeTool) {
      case "ai-audio": return <AIAudioGenerator hasSources={hasSources} sources={selectedSources} chatMessages={chatMessages} onSave={(title, content) => saveOutput("ai-audio", title, content)} />;
      case "ai-video": return <AIVideoGenerator hasSources={hasSources} sources={selectedSources} onSave={(title, content) => saveOutput("ai-video", title, content)} />;
      case "ai-visuals": return <AIVisualsGenerator hasSources={hasSources} sources={selectedSources} onSave={(title, content) => saveOutput("ai-visuals", title, content)} />;
      case "ai-tutor": return <AITutorGenerator hasSources={hasSources} sources={selectedSources} onSave={(title, content) => saveOutput("ai-tutor", title, content)} />;
      case "flashcards": return <FlashcardGenerator hasSources={hasSources} sources={selectedSources} onSave={(title, content) => saveOutput("flashcards", title, content)} />;
      case "quiz": return <QuizGenerator hasSources={hasSources} sources={selectedSources} onSave={(title, content) => saveOutput("quiz", title, content)} />;
      case "mindmap": return <MindMapGenerator hasSources={hasSources} sources={selectedSources} onSave={(title, content) => saveOutput("mindmap", title, content)} />;
      case "slides": return <SlideGenerator hasSources={hasSources} sources={selectedSources} onSave={(title, content) => saveOutput("slides", title, content)} />;
      case "report": return <ReportGenerator hasSources={hasSources} sources={selectedSources} onSave={(title, content) => saveOutput("report", title, content)} />;
      case "infographic": return <InfographicGenerator hasSources={hasSources} sources={selectedSources} onSave={(title, content) => saveOutput("infographic", title, content)} />;
      case "datatable": return <DataTableGenerator hasSources={hasSources} sources={selectedSources} onSave={(title, content) => saveOutput("datatable", title, content)} />;
      default: return (
        <div className="text-center py-10">
          <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
            <Zap className="h-5 w-5 text-primary" />
          </div>
          <h3 className="font-display font-semibold text-foreground mb-1">Studio</h3>
          <p className="text-sm text-muted-foreground">Select a tool from the menu to get started</p>
        </div>
      );
    }
  };

  const allSelected = sources.length > 0 && selectedSourceIds.size === sources.length;

  return (
    <div className="h-screen bg-gradient-hero flex flex-col overflow-hidden text-slate-200">
      {/* Top bar */}
      <div className="border-b border-white/10 bg-white/5 backdrop-blur-sm px-4 py-2 flex items-center gap-3 flex-shrink-0">
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSourcesOpen(!sourcesOpen)}
              className="text-slate-400 hover:text-slate-200 hover:bg-white/10"
            >
              {sourcesOpen ? <PanelLeftClose className="h-4 w-4" /> : <PanelLeftOpen className="h-4 w-4" />}
            </Button>
          </TooltipTrigger>
          <TooltipContent>{sourcesOpen ? "Collapse Sources Panel" : "Expand Sources Panel"}</TooltipContent>
        </Tooltip>
        <Link to="/dashboard" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft className="h-3.5 w-3.5" /> Dashboard
        </Link>
        <div className="h-4 w-px bg-border/50" />
        <input
          value={title}
          onChange={(e) => updateTitle(e.target.value)}
          className="bg-transparent font-display text-sm font-bold text-white outline-none placeholder:text-slate-500 flex-1"
          placeholder="Workspace title..."
        />
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => { setStudioOpen(!studioOpen); if (!studioOpen && !activeTool) setActiveTool("flashcards"); }}
              className="text-slate-400 hover:text-slate-200 hover:bg-white/10"
            >
              {studioOpen ? <PanelRightClose className="h-4 w-4" /> : <PanelRightOpen className="h-4 w-4" />}
            </Button>
          </TooltipTrigger>
          <TooltipContent>{studioOpen ? "Collapse Studio Panel" : "Expand Studio Panel"}</TooltipContent>
        </Tooltip>
      </div>

      {/* Main content with resizable panels */}
      <div className="flex-1 overflow-hidden">
        <ResizablePanelGroup direction="horizontal" className="h-full">
          {/* Collapsed sources strip when not open */}
          {!sourcesOpen && (
            <>
              <div className="w-12 flex flex-col items-center py-4 gap-1.5 border-r border-white/10 bg-white/5 flex-shrink-0">
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button onClick={() => setSourcesOpen(true)} className="mb-2">
                      <Upload className="h-5 w-5 text-primary" />
                    </button>
                  </TooltipTrigger>
                  <TooltipContent side="right">Expand Sources Panel</TooltipContent>
                </Tooltip>

                <Tooltip>
                  <TooltipTrigger asChild>
                    <button
                      onClick={() => { setSourcesOpen(true); fileInputRef.current?.click(); }}
                      className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-400 hover:bg-white/10 hover:text-slate-200 transition-all"
                    >
                      <Plus className="h-4.5 w-4.5" />
                    </button>
                  </TooltipTrigger>
                  <TooltipContent side="right">Add Source</TooltipContent>
                </Tooltip>

                <div className="h-px w-6 bg-white/10 my-1" />

                {/* Show icons for each uploaded source */}
                {sources.map((s) => (
                  <Tooltip key={s.id}>
                    <TooltipTrigger asChild>
                      <button
                        onClick={() => setSourcesOpen(true)}
                        className={`flex h-8 w-8 items-center justify-center rounded-lg transition-all duration-200 ${
                          selectedSourceIds.has(s.id) ? "bg-primary/20 text-primary" : "text-slate-400 hover:bg-white/10 hover:text-slate-200"
                        }`}
                      >
                        {s.type === "pdf" && <FileText className="h-4 w-4" />}
                        {s.type === "youtube" && <Youtube className="h-4 w-4" />}
                        {s.type === "link" && <LinkIcon className="h-4 w-4" />}
                        {s.type === "image" && <Image className="h-4 w-4" />}
                        {s.type === "audio" && <Music className="h-4 w-4" />}
                        {s.type === "video" && <Video className="h-4 w-4" />}
                        {s.type === "docx" && <FileText className="h-4 w-4" />}
                        {s.type === "pptx" && <Presentation className="h-4 w-4" />}
                        {s.type === "text" && <File className="h-4 w-4" />}
                        {!["pdf","youtube","link","image","audio","video","docx","pptx","text"].includes(s.type) && <File className="h-4 w-4" />}
                      </button>
                    </TooltipTrigger>
                    <TooltipContent side="right">{s.name}</TooltipContent>
                  </Tooltip>
                ))}
              </div>
            </>
          )}

          {/* Left Sidebar - Sources (expanded) */}
          {sourcesOpen && (
            <>
              <ResizablePanel defaultSize={20} minSize={15} maxSize={35}>
                <div className="h-full flex flex-col bg-white/5">
                  {/* Sidebar tabs */}
                  <div className="flex border-b border-white/10 flex-shrink-0">
                    {[
                      { key: "sources" as const, icon: Upload, label: "Sources" },
                      { key: "outputs" as const, icon: Sparkles, label: "Outputs" },
                      { key: "notes" as const, icon: StickyNote, label: "Notes" },
                    ].map((tab) => (
                      <button
                        key={tab.key}
                        onClick={() => setLeftSidebarTab(tab.key)}
                        className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 text-xs font-medium transition-colors ${
                          leftSidebarTab === tab.key
                            ? "text-primary border-b-2 border-primary"
                            : "text-slate-400 hover:text-slate-200"
                        }`}
                      >
                        <tab.icon className="h-3.5 w-3.5" />
                        {tab.label}
                      </button>
                    ))}
                  </div>

                  <ScrollArea className="flex-1 p-4">
                    {leftSidebarTab === "sources" && (
                      <div
                        onDrop={handleFileDrop}
                        onDragOver={handleDragOver}
                        onDragLeave={handleDragLeave}
                      >
                        <input
                          ref={fileInputRef}
                          type="file"
                          multiple
                          accept={ACCEPTED_FILE_TYPES}
                          className="hidden"
                          onChange={(e) => {
                            if (e.target.files && e.target.files.length > 0) {
                              uploadFiles(e.target.files);
                              e.target.value = "";
                            }
                          }}
                        />

                        <div className="flex items-center justify-between mb-3">
                          <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider">Sources</h3>
                          <div className="flex items-center gap-1">
                            <Button variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={() => fileInputRef.current?.click()}>
                              <Upload className="h-3.5 w-3.5" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setShowAddSource(!showAddSource)}>
                              <Plus className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>

                        <AnimatePresence>
                          {showAddSource && (
                            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="mb-4 space-y-2 overflow-hidden">
                              <div className="flex gap-2">
                                <Input placeholder="Paste URL or YouTube link..." value={linkInput} onChange={(e) => setLinkInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && handleAddLink()} className="text-sm bg-white/10 border-white/10 text-slate-200 placeholder:text-slate-500" />
                                <Button size="sm" onClick={handleAddLink} disabled={!linkInput.trim()}>
                                  <Plus className="h-3.5 w-3.5" />
                                </Button>
                              </div>
                              <Button variant="ghost" size="sm" className="w-full bg-transparent border border-white/10 text-slate-400 hover:bg-white/10 hover:text-slate-200 hover:border-white/20 transition-all" onClick={() => fileInputRef.current?.click()}>
                                <Upload className="h-3.5 w-3.5 mr-1.5" /> Browse Files
                              </Button>
                            </motion.div>
                          )}
                        </AnimatePresence>

                        {isDragOver && (
                          <div className="mb-4 rounded-xl border-2 border-dashed border-primary bg-primary/10 p-6 text-center">
                            <Upload className="h-8 w-8 mx-auto mb-2 text-primary animate-bounce" />
                            <p className="text-sm font-medium text-primary">Drop files here</p>
                          </div>
                        )}

                        {uploadingFiles.length > 0 && (
                          <div className="space-y-2 mb-4">
                            {uploadingFiles.map((uf, i) => (
                              <motion.div key={`uploading-${i}`} initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="rounded-lg border border-white/10 bg-white/10 p-2.5">
                                <div className="flex items-center gap-2 mb-1.5">
                                  {uf.done ? (
                                    <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center">
                                      <CheckSquare className="h-3 w-3 text-primary" />
                                    </div>
                                  ) : (
                                    <Loader2 className="h-4 w-4 animate-spin text-primary" />
                                  )}
                                  <span className="flex-1 text-xs truncate text-slate-200">{uf.name}</span>
                                  <span className="text-[10px] text-slate-400">{uf.progress}%</span>
                                </div>
                                <div className="relative h-1.5 w-full rounded-full bg-white/10 overflow-hidden">
                                  <motion.div className="absolute inset-y-0 left-0 bg-primary rounded-full" initial={{ width: "0%" }} animate={{ width: `${uf.progress}%` }} transition={{ duration: 0.3 }} />
                                </div>
                              </motion.div>
                            ))}
                          </div>
                        )}

                        {sources.length === 0 && !isDragOver && uploadingFiles.length === 0 ? (
                          <div className="text-center py-10">
                            <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                              <Upload className="h-5 w-5 text-primary" />
                            </div>
                            <p className="text-sm text-slate-400 mb-1">Add sources to get started</p>
                            <p className="text-xs text-slate-500 mb-3">Drag & drop files or click below</p>
                            <div className="flex flex-col gap-2">
                              <Button variant="default" size="sm" onClick={() => fileInputRef.current?.click()}>
                                <Upload className="h-3.5 w-3.5 mr-1" /> Browse Files
                              </Button>
                              <Button variant="default" size="sm" onClick={() => setShowAddSource(true)}>
                                <LinkIcon className="h-3.5 w-3.5 mr-1" /> Add Link
                              </Button>
                            </div>
                          </div>
                        ) : sources.length > 0 && (
                          <div className="space-y-1">
                            <button onClick={toggleSelectAll} className="flex items-center gap-2 w-full rounded-lg px-2.5 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 hover:bg-white/10 transition-colors">
                              <Checkbox checked={allSelected} className="h-3.5 w-3.5 pointer-events-none" />
                              Select All ({selectedSourceIds.size}/{sources.length})
                            </button>
                            <div className="h-px bg-white/10 my-1" />
                            {sources.map((s) => (
                              <div key={s.id} className={`flex items-center gap-2 rounded-lg border p-2.5 group cursor-pointer transition-colors ${selectedSourceIds.has(s.id) ? "border-primary/30 bg-primary/10" : "border-white/10 bg-white/5"}`} onClick={() => toggleSourceSelection(s.id)}>
                                <Checkbox checked={selectedSourceIds.has(s.id)} className="h-3.5 w-3.5 flex-shrink-0 pointer-events-none" />
                                {getSourceIcon(s.type)}
                                <span className="flex-1 text-sm truncate text-slate-200">{s.name}</span>
                                <button onClick={(e) => { e.stopPropagation(); removeSource(s.id); }} className="opacity-0 group-hover:opacity-100 transition-opacity">
                                  <X className="h-3.5 w-3.5 text-slate-400 hover:text-red-400" />
                                </button>
                              </div>
                            ))}
                            <div className="mt-4 pt-4 border-t border-white/10 space-y-2">
                              <Button variant="default" size="sm" className="w-full" onClick={() => fileInputRef.current?.click()}>
                                <Upload className="h-3.5 w-3.5 mr-1.5" /> Browse Files
                              </Button>
                              <Button variant="default" size="sm" className="w-full" onClick={() => setShowAddSource(!showAddSource)}>
                                <LinkIcon className="h-3.5 w-3.5 mr-1.5" /> Add Link
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {leftSidebarTab === "outputs" && (
                      <div className="space-y-3">
                        {/* Filter buttons */}
                        <div className="flex flex-wrap gap-1.5">
                          <button
                            onClick={() => setOutputFilter("all")}
                            className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                              outputFilter === "all"
                                ? "bg-primary/20 text-primary"
                                : "bg-white/5 text-slate-400 hover:text-slate-200"
                            }`}
                          >
                            All ({outputs.length})
                          </button>
                          {Array.from(new Set(outputs.map((o) => o.type))).map((type) => (
                            <button
                              key={type}
                              onClick={() => setOutputFilter(type)}
                              className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                                outputFilter === type
                                  ? "bg-primary/20 text-primary"
                                  : "bg-white/5 text-slate-400 hover:text-slate-200"
                              }`}
                            >
                              {type} ({outputs.filter((o) => o.type === type).length})
                            </button>
                          ))}
                        </div>

                        {/* Outputs list */}
                        {outputs.length === 0 ? (
                          <div className="text-center py-10">
                            <Sparkles className="h-8 w-8 mx-auto mb-3 text-primary/40" />
                            <p className="text-sm text-slate-400">Generated outputs will appear here</p>
                          </div>
                        ) : (
                          <div className="space-y-2">
                            {outputs
                              .filter((o) => outputFilter === "all" || o.type === outputFilter)
                              .map((output) => {
                                const toolInfo = studioTools.find((t) => t.id === output.type);
                                const Icon = toolInfo?.icon || FileText;
                                return (
                                  <div
                                    key={output.id}
                                    className="group rounded-lg border border-white/10 bg-white/5 p-3 hover:bg-white/10 transition-colors"
                                  >
                                    <div className="flex items-start gap-2">
                                      <div className="flex-shrink-0 mt-0.5">
                                        <Icon className="h-4 w-4 text-primary" />
                                      </div>
                                      <div className="flex-1 min-w-0">
                                        <h4 className="text-sm font-medium text-slate-200 truncate">
                                          {output.title}
                                        </h4>
                                        <div className="flex items-center gap-2 mt-1">
                                          <span className="text-xs text-slate-500">
                                            {new Date(output.created_at).toLocaleDateString()}
                                          </span>
                                          <span className="text-xs text-slate-600">•</span>
                                          <span className="text-xs text-slate-500 capitalize">
                                            {output.type.replace(/-/g, " ")}
                                          </span>
                                        </div>
                                      </div>
                                      <button
                                        onClick={() => deleteOutput(output.id)}
                                        className="flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                                      >
                                        <X className="h-4 w-4 text-slate-400 hover:text-red-400" />
                                      </button>
                                    </div>
                                  </div>
                                );
                              })}
                          </div>
                        )}
                      </div>
                    )}

                    {leftSidebarTab === "notes" && (
                      <Textarea placeholder="Take notes here..." value={notes} onChange={(e) => setNotes(e.target.value)} className="min-h-[300px] resize-none border-none bg-transparent p-0 text-sm text-slate-200 focus-visible:ring-0" />
                    )}
                  </ScrollArea>
                </div>
              </ResizablePanel>

              <ResizableHandle withHandle />
            </>
          )}

          {/* Center - AI Chat */}
          <ResizablePanel defaultSize={studioOpen ? 50 : 80} minSize={30}>
            <div className="h-full flex flex-col">
              <div className="border-b border-white/10 bg-white/5 px-6 py-3 flex items-center gap-2 flex-shrink-0">
                <Brain className="h-5 w-5 text-primary" />
                <span className="font-display font-semibold text-slate-100">AI Chat</span>
                <span className="text-xs text-slate-400">— Ask about your sources</span>
              </div>

              <div ref={chatContainerRef} className="flex-1 overflow-y-auto px-6 py-8">
                {chatMessages.length === 0 ? (
                  <div className="h-full flex items-center justify-center">
                    <div className="text-center max-w-md space-y-4">
                      <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10">
                        <Brain className="h-8 w-8 text-primary" />
                      </div>
                       <h2 className="font-display text-xl font-bold text-slate-100">Ask anything about your sources</h2>
                       <p className="text-slate-400 text-sm leading-relaxed">
                         {sources.length === 0
                           ? "Add some sources first, then ask questions to get cited answers."
                           : `You have ${sources.length} source${sources.length > 1 ? "s" : ""}. Upload files to get an automatic overview.`}
                       </p>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-6 max-w-3xl mx-auto">
                    {hasMoreMessages && (
                      <div className="text-center pb-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={loadMoreMessages}
                          disabled={loadingMore}
                          className="text-xs text-muted-foreground hover:text-foreground"
                        >
                          {loadingMore ? (
                            <><Loader2 className="h-3 w-3 animate-spin mr-1.5" /> Loading...</>
                          ) : (
                            <><RefreshCw className="h-3 w-3 mr-1.5" /> Load earlier messages</>
                          )}
                        </Button>
                      </div>
                    )}
                    {chatMessages.map((msg, i) => (
                      <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                        <div className={`max-w-[85%] rounded-2xl px-5 py-3.5 text-sm leading-relaxed ${msg.role === "user" ? "bg-primary text-primary-foreground" : "bg-white/10 border border-white/10 text-slate-200"}`}>
                          {msg.role === "assistant" ? (
                            <div className="prose prose-sm dark:prose-invert max-w-none [&_p]:mb-3 [&_p:last-child]:mb-0 [&_ul]:my-3 [&_ol]:my-3 [&_li]:mb-1.5 [&_h1]:mt-4 [&_h1]:mb-3 [&_h2]:mt-4 [&_h2]:mb-2 [&_h3]:mt-3 [&_h3]:mb-2">
                              <ReactMarkdown>{msg.content || "..."}</ReactMarkdown>
                            </div>
                          ) : msg.content}
                        </div>
                      </div>
                    ))}
                    {isStreaming && chatMessages[chatMessages.length - 1]?.content === "" && (
                      <div className="flex justify-start">
                        <div className="bg-white/10 border border-white/10 rounded-2xl px-5 py-3.5">
                          <Loader2 className="h-4 w-4 animate-spin text-primary" />
                        </div>
                      </div>
                    )}
                    <div ref={chatEndRef} />
                  </div>
                )}
              </div>

              <div className="border-t border-white/10 bg-white/5 p-4 flex-shrink-0">
                <div className="flex gap-2 max-w-3xl mx-auto">
                  <Input placeholder="Ask about your sources..." value={chatInput} onChange={(e) => setChatInput(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && chatInput.trim() && !isStreaming) sendMessage(); }} className="bg-white/10 border-white/10 text-slate-200 placeholder:text-slate-500" disabled={isStreaming} />
                  <Button size="icon" disabled={!chatInput.trim() || isStreaming} onClick={sendMessage}>
                    {isStreaming ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
            </div>
          </ResizablePanel>

          {/* Right Studio Panel */}
          {studioOpen && (
            <>
              <ResizableHandle withHandle />
              <ResizablePanel defaultSize={30} minSize={20} maxSize={45}>
                <div className="h-full flex flex-col bg-white/5">
                  <ResizablePanelGroup direction="vertical" className="h-full">
                    {/* Tool menu - collapsible top section */}
                    <ResizablePanel defaultSize={35} minSize={8} maxSize={60} collapsible>
                      <div className="h-full flex flex-col overflow-hidden">
                        <div className="px-4 py-3 border-b border-white/10 flex-shrink-0">
                          <div className="flex items-center gap-2">
                            <Zap className="h-4 w-4 text-primary" />
                            <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider">Studio</span>
                          </div>
                        </div>
                        <ScrollArea className="flex-1">
                          <div className="p-2 space-y-0.5">
                            {studioTools.map((tool) => (
                              <button
                                key={tool.id}
                                onClick={() => handleToolClick(tool.id)}
                                className={`flex items-center gap-2.5 w-full rounded-lg px-3 py-2.5 text-sm font-medium transition-all ${
                                  activeTool === tool.id
                                    ? "bg-primary/20 text-primary"
                                    : "text-slate-400 hover:bg-white/10 hover:text-slate-200"
                                }`}
                              >
                                <tool.icon className="h-4 w-4 flex-shrink-0" />
                                <span className="truncate">{tool.label}</span>
                              </button>
                            ))}
                          </div>
                        </ScrollArea>
                      </div>
                    </ResizablePanel>

                    <ResizableHandle withHandle />

                    {/* Studio content - fills remaining space */}
                    <ResizablePanel defaultSize={65} minSize={40}>
                      <ScrollArea className="h-full">
                        <div className="p-5">
                          {renderStudioContent()}
                        </div>
                      </ScrollArea>
                    </ResizablePanel>
                  </ResizablePanelGroup>
                </div>
              </ResizablePanel>
            </>
          )}

          {/* Collapsed studio strip when not open */}
          {!studioOpen && (
            <div className="w-12 flex flex-col items-center py-4 gap-1 border-l border-white/10 bg-white/5 flex-shrink-0">
              <Tooltip>
                <TooltipTrigger asChild>
                  <button onClick={() => { setStudioOpen(true); if (!activeTool) setActiveTool("flashcards"); }} className="mb-3">
                    <Zap className="h-5 w-5 text-primary" />
                  </button>
                </TooltipTrigger>
                <TooltipContent side="left">Expand Studio Panel</TooltipContent>
              </Tooltip>
              {studioTools.map((tool) => (
                <Tooltip key={tool.id}>
                  <TooltipTrigger asChild>
                    <button
                      onClick={() => { setActiveTool(tool.id); setStudioOpen(true); }}
                      className={`flex h-9 w-9 items-center justify-center rounded-lg transition-all duration-200 ${
                        activeTool === tool.id ? "bg-primary/20 text-primary" : "text-slate-400 hover:bg-white/10 hover:text-slate-200"
                      }`}
                    >
                      <tool.icon className="h-4.5 w-4.5" />
                    </button>
                  </TooltipTrigger>
                  <TooltipContent side="left">{tool.label}</TooltipContent>
                </Tooltip>
              ))}
            </div>
          )}
        </ResizablePanelGroup>
      </div>
    </div>
  );
};

export default WorkspaceView;
