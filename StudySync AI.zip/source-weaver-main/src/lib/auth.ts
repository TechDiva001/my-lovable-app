import { supabase } from "@/integrations/supabase/client";

export type AuthFormData = {
  email: string;
  password: string;
  fullName?: string;
};

export const signUp = async ({ email, password, fullName }: AuthFormData) => {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: { full_name: fullName },
      emailRedirectTo: window.location.origin,
    },
  });
  return { data, error };
};

export const signIn = async ({ email, password }: AuthFormData) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  return { data, error };
};

export const signOut = async () => {
  const { error } = await supabase.auth.signOut();
  return { error };
};
