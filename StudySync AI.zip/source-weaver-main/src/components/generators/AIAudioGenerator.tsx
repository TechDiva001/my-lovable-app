import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Volume2, Pause, Play, Square, Loader2, RotateCcw } from "lucide-react";
import { motion } from "framer-motion";
import { generateAI } from "@/lib/ai";
import { toast } from "sonner";

type Source = { id: string; type: string; name: string };

const AIAudioGenerator = ({ hasSources, sources, chatMessages, onSave }: { hasSources: boolean; sources: Source[]; chatMessages?: { role: string; content: string }[]; onSave?: (title: string, content: any) => void }) => {
  const [script, setScript] = useState("");
  const [generating, setGenerating] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [paused, setPaused] = useState(false);
  const [progress, setProgress] = useState(0);
  const [rate, setRate] = useState(1);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    return () => {
      window.speechSynthesis.cancel();
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  const getLatestAssistantMessage = () => {
    if (!chatMessages) return null;
    for (let i = chatMessages.length - 1; i >= 0; i--) {
      if (chatMessages[i].role === "assistant" && chatMessages[i].content.trim()) {
        return chatMessages[i].content;
      }
    }
    return null;
  };

  const handleGenerate = async () => {
    if (!hasSources) return;
    setGenerating(true);
    try {
      const lastResponse = getLatestAssistantMessage();
      const sourceNames = sources.map((s) => s.name).join(", ");

      const prompt = lastResponse
        ? `Convert this AI-generated explanation into a clear, well-paced narration script. Keep all key information but make it flow naturally when read aloud. Use proper punctuation for pacing — commas for brief pauses, periods for full stops, and ellipses for dramatic pauses. Remove any markdown formatting, bullet points, or headers. Make it conversational and engaging:\n\n${lastResponse}`
        : `Create a comprehensive audio narration script about these study sources: ${sourceNames}. Make it educational, well-paced, and engaging. Use proper punctuation for natural pacing — commas for brief pauses, periods for full stops. Keep it conversational as if a teacher is explaining the material.`;

      const result = await generateAI([
        {
          role: "system",
          content: "You are an expert narrator who creates clear, engaging audio scripts for educational content. Write in a natural speaking style with proper punctuation for pacing. No markdown, no bullet points, no headers — just flowing narration text.",
        },
        { role: "user", content: prompt },
      ]);

      setScript(result);
      toast.success("Audio script ready! Click play to listen.");
      onSave?.(`Audio Script - ${sources.map((s) => s.name).join(", ").slice(0, 30)}`, { script: result });
    } catch {
      toast.error("Failed to generate audio script");
    }
    setGenerating(false);
  };

  const handlePlay = () => {
    if (paused) {
      window.speechSynthesis.resume();
      setPaused(false);
      setSpeaking(true);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(script);
    utterance.rate = rate;
    utterance.pitch = 1;
    utterance.volume = 1;

    // Try to pick a good English voice
    const voices = window.speechSynthesis.getVoices();
    const preferred = voices.find((v) => v.name.includes("Google") && v.lang.startsWith("en")) ||
      voices.find((v) => v.lang.startsWith("en") && v.localService === false) ||
      voices.find((v) => v.lang.startsWith("en"));
    if (preferred) utterance.voice = preferred;

    const totalChars = script.length;
    let charIndex = 0;

    utterance.onboundary = (e) => {
      charIndex = e.charIndex;
      setProgress(Math.round((charIndex / totalChars) * 100));
    };

    utterance.onend = () => {
      setSpeaking(false);
      setPaused(false);
      setProgress(100);
      if (intervalRef.current) clearInterval(intervalRef.current);
    };

    utterance.onerror = () => {
      setSpeaking(false);
      setPaused(false);
    };

    utteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
    setSpeaking(true);
    setProgress(0);
  };

  const handlePause = () => {
    window.speechSynthesis.pause();
    setPaused(true);
    setSpeaking(false);
  };

  const handleStop = () => {
    window.speechSynthesis.cancel();
    setSpeaking(false);
    setPaused(false);
    setProgress(0);
  };

  if (!hasSources) {
    return (
      <div className="text-center py-10">
        <Volume2 className="h-8 w-8 mx-auto mb-3 text-primary/40" />
        <p className="text-sm text-muted-foreground">Add sources and chat with AI first, then listen to audio narration</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-4">
        <Volume2 className="h-5 w-5 text-primary" />
        <h3 className="font-display font-semibold text-slate-100">AI Audio</h3>
        <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">TTS</span>
      </div>

      <p className="text-xs text-muted-foreground">
        Generates an audio narration from your latest AI chat response or source material. The AI reads with proper pacing and punctuation.
      </p>

      <Button onClick={handleGenerate} disabled={generating} className="w-full" variant="default">
        {generating ? <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Generating Script...</> : <><RotateCcw className="h-4 w-4 mr-2" /> Generate Audio Script</>}
      </Button>

      {script && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
          {/* Playback controls */}
          <div className="rounded-xl border border-white/10 bg-white/5 p-4 space-y-3">
            <div className="flex items-center gap-3">
              {speaking ? (
                <Button size="icon" variant="ghost" onClick={handlePause} className="h-10 w-10 rounded-full bg-primary/20 text-primary hover:bg-primary/30">
                  <Pause className="h-5 w-5" />
                </Button>
              ) : (
                <Button size="icon" variant="ghost" onClick={handlePlay} className="h-10 w-10 rounded-full bg-primary/20 text-primary hover:bg-primary/30">
                  <Play className="h-5 w-5" />
                </Button>
              )}
              <Button size="icon" variant="ghost" onClick={handleStop} className="h-8 w-8 text-muted-foreground hover:text-foreground">
                <Square className="h-4 w-4" />
              </Button>

              <div className="flex-1">
                <div className="relative h-2 w-full rounded-full bg-white/10 overflow-hidden">
                  <motion.div
                    className="absolute inset-y-0 left-0 bg-primary rounded-full"
                    animate={{ width: `${progress}%` }}
                    transition={{ duration: 0.3 }}
                  />
                </div>
              </div>
              <span className="text-xs text-muted-foreground w-10 text-right">{progress}%</span>
            </div>

            {/* Speed control */}
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">Speed:</span>
              {[0.75, 1, 1.25, 1.5].map((r) => (
                <button
                  key={r}
                  onClick={() => setRate(r)}
                  className={`text-xs px-2 py-1 rounded-md transition-colors ${rate === r ? "bg-primary/20 text-primary" : "text-muted-foreground hover:bg-white/10"}`}
                >
                  {r}x
                </button>
              ))}
            </div>
          </div>

          {/* Script preview */}
          <div className="rounded-xl border border-white/10 bg-white/5 p-4 max-h-48 overflow-y-auto">
            <p className="text-xs text-muted-foreground mb-2 font-semibold uppercase tracking-wider">Script Preview</p>
            <p className="text-sm text-slate-300 leading-relaxed">{script.slice(0, 500)}{script.length > 500 && "..."}</p>
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default AIAudioGenerator;
