import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Table2, Download, RefreshCw, Loader2 } from "lucide-react";
import { generateAI } from "@/lib/ai";
import { toast } from "sonner";

type Source = { id: string; type: string; name: string };

const DataTableGenerator = ({ hasSources, sources, onSave }: { hasSources: boolean; sources: Source[]; onSave?: (title: string, content: any) => void }) => {
  const [data, setData] = useState<{ headers: string[]; rows: string[][] } | null>(null);
  const [generating, setGenerating] = useState(false);

  const handleGenerate = async () => {
    if (!hasSources) return;
    setGenerating(true);
    try {
      const sourceNames = sources.map((s) => s.name).join(", ");
      const result = await generateAI([
        {
          role: "system",
          content: `Extract key data from the user's study sources and organize it into a table. Return ONLY valid JSON: {"headers":["Col1","Col2","Col3"],"rows":[["val1","val2","val3"]]}. Include 5-8 rows. No markdown, no code fences.`,
        },
        { role: "user", content: `Create a data table from these sources: ${sourceNames}` },
      ]);
      const cleaned = result.replace(/```json?\n?/g, "").replace(/```/g, "").trim();
      const parsed = JSON.parse(cleaned);
      if (parsed.headers && parsed.rows) {
        setData(parsed);
        onSave?.(`Data Table - ${sourceNames.slice(0, 30)}`, parsed);
      } else {
        toast.error("Failed to parse table data");
      }
    } catch {
      toast.error("Failed to generate table");
    }
    setGenerating(false);
  };

  const exportCSV = () => {
    if (!data) return;
    const csv = [data.headers.join(","), ...data.rows.map((r) => r.map((c) => `"${c}"`).join(","))].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "data-table.csv"; a.click();
    URL.revokeObjectURL(url);
  };

  if (!data) {
    return (
      <div className="text-center py-8">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10">
          <Table2 className="h-7 w-7 text-primary" />
        </div>
        <h3 className="font-display text-lg font-bold text-foreground mb-2">Data Table</h3>
        <p className="text-muted-foreground text-sm mb-6">
          {hasSources ? "Extract structured data from sources." : "Add sources first."}
        </p>
        <Button onClick={handleGenerate} disabled={!hasSources || generating}>
          {generating ? <Loader2 className="h-4 w-4 animate-spin mr-1.5" /> : <Table2 className="h-4 w-4 mr-1.5" />}
          {generating ? "Generating..." : "Generate Table"}
        </Button>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display font-bold text-foreground">Data Table</h3>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={exportCSV}>
            <Download className="h-3.5 w-3.5 mr-1" /> CSV
          </Button>
          <Button variant="ghost" size="sm" onClick={handleGenerate} disabled={generating}>
            {generating ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}
          </Button>
        </div>
      </div>
      <div className="rounded-xl border border-border/50 overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              {data.headers.map((h, i) => (
                <TableHead key={i} className="font-display font-semibold text-xs">{h}</TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.rows.map((row, i) => (
              <TableRow key={i}>
                {row.map((cell, j) => (
                  <TableCell key={j} className="text-sm">{cell}</TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default DataTableGenerator;
