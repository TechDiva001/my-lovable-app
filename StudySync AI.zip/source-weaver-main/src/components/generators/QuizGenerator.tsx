import { useState } from "react";
import { Button } from "@/components/ui/button";
import { HelpCircle, CheckCircle2, XCircle, Loader2 } from "lucide-react";
import { generateAI } from "@/lib/ai";
import { toast } from "sonner";

type Source = { id: string; type: string; name: string };
type Question = { question: string; options: string[]; correct: number; explanation: string };
const difficulties = ["Beginner", "Intermediate", "Advanced"] as const;

const QuizGenerator = ({ hasSources, sources, onSave }: { hasSources: boolean; sources: Source[]; onSave?: (title: string, content: any) => void }) => {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQ, setCurrentQ] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);
  const [difficulty, setDifficulty] = useState<(typeof difficulties)[number]>("Beginner");
  const [generating, setGenerating] = useState(false);

  const handleGenerate = async () => {
    if (!hasSources) return;
    setGenerating(true);
    setCurrentQ(0); setSelected(null); setScore(0); setFinished(false);
    try {
      const sourceNames = sources.map((s) => s.name).join(", ");
      const result = await generateAI([
        {
          role: "system",
          content: `Generate exactly 5 ${difficulty}-level multiple choice questions based on the user's study sources. Return ONLY a valid JSON array of objects with keys: "question" (string), "options" (array of 4 strings), "correct" (index 0-3 of correct option), "explanation" (string). No markdown, no code fences.`,
        },
        { role: "user", content: `Create a quiz from these sources: ${sourceNames}` },
      ]);
      const cleaned = result.replace(/```json?\n?/g, "").replace(/```/g, "").trim();
      const parsed = JSON.parse(cleaned);
      if (Array.isArray(parsed) && parsed.length > 0) {
        setQuestions(parsed);
        onSave?.(`Quiz (${difficulty}) - ${sourceNames.slice(0, 30)}`, parsed);
      } else {
        toast.error("Failed to parse quiz");
      }
    } catch {
      toast.error("Failed to generate quiz");
    }
    setGenerating(false);
  };

  const handleSelect = (idx: number) => {
    if (selected !== null) return;
    setSelected(idx);
    if (idx === questions[currentQ].correct) setScore(score + 1);
  };

  const handleNext = () => {
    if (currentQ < questions.length - 1) {
      setCurrentQ(currentQ + 1);
      setSelected(null);
    } else {
      setFinished(true);
    }
  };

  if (questions.length === 0) {
    return (
      <div className="text-center py-8">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10">
          <HelpCircle className="h-7 w-7 text-primary" />
        </div>
        <h3 className="font-display text-lg font-bold text-slate-100 mb-2">Quiz Generator</h3>
        <p className="text-sm mb-4 text-slate-300">
          {hasSources ? "Generate quizzes from your sources." : "Add sources first."}
        </p>
        <div className="flex gap-2 justify-center mb-4">
          {difficulties.map((d) => (
            <Button key={d} variant="default" size="sm" onClick={() => setDifficulty(d)} className={difficulty === d ? "opacity-100" : "opacity-70 hover:opacity-100"}>
              {d}
            </Button>
          ))}
        </div>
        <Button onClick={handleGenerate} disabled={!hasSources || generating}>
          {generating ? <Loader2 className="h-4 w-4 animate-spin mr-1.5" /> : <HelpCircle className="h-4 w-4 mr-1.5" />}
          {generating ? "Generating..." : "Generate Quiz"}
        </Button>
      </div>
    );
  }

  if (finished) {
    return (
      <div className="text-center py-8">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10">
          <CheckCircle2 className="h-7 w-7 text-primary" />
        </div>
        <h3 className="font-display text-xl font-bold text-foreground mb-2">Quiz Complete!</h3>
        <p className="text-3xl font-bold text-primary mb-1">{score}/{questions.length}</p>
        <p className="text-muted-foreground text-sm mb-6">
          {score === questions.length ? "Perfect score!" : score >= questions.length / 2 ? "Good job!" : "Keep studying!"}
        </p>
        <Button onClick={handleGenerate} disabled={generating}>
          {generating ? <Loader2 className="h-4 w-4 animate-spin mr-1.5" /> : null}
          Try Again
        </Button>
      </div>
    );
  }

  const q = questions[currentQ];
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display font-bold text-sm text-foreground">Question {currentQ + 1}/{questions.length}</h3>
        <span className="text-xs text-muted-foreground">Score: {score}</span>
      </div>
      <p className="font-semibold text-foreground mb-4">{q.question}</p>
      <div className="space-y-2">
        {q.options.map((opt, i) => (
          <button
            key={i}
            onClick={() => handleSelect(i)}
            className={`w-full text-left rounded-lg border p-3 text-sm transition-all ${
              selected === null
                ? "border-border/50 hover:border-primary/30 hover:bg-card text-foreground"
                : i === q.correct
                ? "border-primary/50 bg-primary/10 text-foreground"
                : i === selected
                ? "border-destructive/50 bg-destructive/10 text-foreground"
                : "border-border/50 opacity-50 text-foreground"
            }`}
          >
            <div className="flex items-center gap-2">
              {selected !== null && i === q.correct && <CheckCircle2 className="h-4 w-4 text-primary flex-shrink-0" />}
              {selected !== null && i === selected && i !== q.correct && <XCircle className="h-4 w-4 text-destructive flex-shrink-0" />}
              {opt}
            </div>
          </button>
        ))}
      </div>
      {selected !== null && (
        <div className="mt-4 rounded-lg bg-card/50 border border-border/50 p-3">
          <p className="text-xs text-muted-foreground">{q.explanation}</p>
        </div>
      )}
      {selected !== null && (
        <Button className="w-full mt-4" onClick={handleNext}>
          {currentQ < questions.length - 1 ? "Next Question" : "See Results"}
        </Button>
      )}
    </div>
  );
};

export default QuizGenerator;
