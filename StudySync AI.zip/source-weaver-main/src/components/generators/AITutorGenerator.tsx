import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { GraduationCap, Send, Loader2, RotateCcw } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { streamAI } from "@/lib/ai";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";

type Source = { id: string; type: string; name: string };
type TutorMessage = { role: "tutor" | "student"; content: string };

const TUTOR_SYSTEM_PROMPT = `You are an expert AI Tutor — a patient, encouraging, and knowledgeable teacher. Your role is to teach step-by-step as if writing on a whiteboard.

Rules:
- Break down complex concepts into small, digestible steps
- Use numbered steps when explaining processes
- Use analogies and real-world examples
- Ask comprehension check questions after key concepts
- Use "Let me write this on the board..." or "Now, pay attention to this..." for emphasis
- Use emojis sparingly for engagement (📝 ✅ 💡 ⚡ 🎯)
- If the student says they don't understand, try a completely different approach
- Be warm and encouraging: "Great question!", "You're getting it!"
- Format key terms in **bold**
- Use markdown formatting for clarity`;

const AITutorGenerator = ({ hasSources, sources, onSave }: { hasSources: boolean; sources: Source[]; onSave?: (title: string, content: any) => void }) => {
  const [messages, setMessages] = useState<TutorMessage[]>([]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [started, setStarted] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const startSession = async () => {
    setStarted(true);
    setStreaming(true);
    const sourceNames = sources.map((s) => s.name).join(", ");

    const introPrompt = `The student has these study materials: ${sourceNames}. Introduce yourself as their tutor, briefly preview what you'll cover based on their sources, and ask what they'd like to learn first. Keep it warm and inviting.`;

    setMessages([{ role: "tutor", content: "" }]);

    try {
      await streamAI(
        [
          { role: "system", content: TUTOR_SYSTEM_PROMPT },
          { role: "user", content: introPrompt },
        ],
        (text) => {
          setMessages([{ role: "tutor", content: text }]);
        }
      );
    } catch {
      toast.error("Failed to start tutor session");
    }
    setStreaming(false);
  };

  const sendMessage = async () => {
    if (!input.trim() || streaming) return;
    const studentMsg: TutorMessage = { role: "student", content: input };
    const updated = [...messages, studentMsg];
    setMessages(updated);
    setInput("");
    setStreaming(true);

    const sourceNames = sources.map((s) => s.name).join(", ");

    // Build AI message history
    const aiMessages = [
      { role: "system" as const, content: `${TUTOR_SYSTEM_PROMPT}\n\nStudent's sources: ${sourceNames}` },
      ...updated.map((m) => ({
        role: (m.role === "tutor" ? "assistant" : "user") as "assistant" | "user",
        content: m.content,
      })),
    ];

    setMessages((prev) => [...prev, { role: "tutor", content: "" }]);

    try {
      await streamAI(aiMessages, (text) => {
        setMessages((prev) => {
          const copy = [...prev];
          copy[copy.length - 1] = { role: "tutor", content: text };
          return copy;
        });
      });
    } catch {
      toast.error("Tutor encountered an error");
    }
    setStreaming(false);
  };

  if (!hasSources) {
    return (
      <div className="text-center py-10">
        <GraduationCap className="h-8 w-8 mx-auto mb-3 text-primary/40" />
        <p className="text-sm text-muted-foreground">Add sources to start an AI Tutor session</p>
      </div>
    );
  }

  if (!started) {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2 mb-4">
          <GraduationCap className="h-5 w-5 text-primary" />
          <h3 className="font-display font-semibold text-foreground">AI Tutor Mode</h3>
          <span className="text-xs bg-accent/10 text-accent px-2 py-0.5 rounded-full">Interactive</span>
        </div>

        <div className="rounded-xl border border-white/10 bg-gradient-to-br from-primary/5 to-accent/5 p-6 text-center space-y-4">
          <div className="mx-auto h-20 w-20 rounded-2xl bg-primary/10 flex items-center justify-center">
            <GraduationCap className="h-10 w-10 text-primary" />
          </div>
          <h4 className="font-display font-bold text-foreground text-lg">Your Personal AI Teacher</h4>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Start an interactive tutoring session. Your AI tutor will teach you step-by-step, 
            answer questions, check your understanding, and adapt to your pace.
          </p>
          <Button onClick={startSession} className="w-full" variant="default">
            <GraduationCap className="h-4 w-4 mr-2" /> Start Tutoring Session
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full -m-5">
      {/* Header */}
      <div className="px-4 py-3 border-b border-white/10 flex items-center gap-2 flex-shrink-0">
        <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
          <GraduationCap className="h-4 w-4 text-primary" />
        </div>
        <div>
          <span className="text-sm font-semibold text-foreground">AI Tutor</span>
          <span className="text-xs text-muted-foreground ml-2">{streaming ? "Teaching..." : "Ready"}</span>
        </div>
        <Button size="sm" variant="ghost" onClick={() => { setStarted(false); setMessages([]); }} className="ml-auto text-xs">
          <RotateCcw className="h-3 w-3 mr-1" /> New Session
        </Button>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 px-4 py-4">
        <div className="space-y-4">
          <AnimatePresence initial={false}>
            {messages.map((msg, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex ${msg.role === "student" ? "justify-end" : "justify-start"}`}
              >
                <div className={`max-w-[90%] rounded-2xl px-4 py-3 text-sm ${
                  msg.role === "student"
                    ? "bg-primary text-primary-foreground"
                    : "bg-white/10 border border-white/10 text-slate-200"
                }`}>
                  {msg.role === "tutor" ? (
                    <div className="prose prose-sm dark:prose-invert max-w-none [&_p]:mb-2 [&_p:last-child]:mb-0">
                      <ReactMarkdown>{msg.content || "..."}</ReactMarkdown>
                    </div>
                  ) : msg.content}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
          {streaming && messages[messages.length - 1]?.content === "" && (
            <div className="flex justify-start">
              <div className="bg-white/10 border border-white/10 rounded-2xl px-4 py-3">
                <Loader2 className="h-4 w-4 animate-spin text-primary" />
              </div>
            </div>
          )}
          <div ref={chatEndRef} />
        </div>
      </ScrollArea>

      {/* Input */}
      <div className="border-t border-white/10 p-3 flex-shrink-0">
        <div className="flex gap-2">
          <Input
            placeholder="Ask your tutor..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && !streaming) sendMessage(); }}
            className="bg-white/10 border-white/10 text-slate-200 placeholder:text-slate-500 text-sm"
            disabled={streaming}
          />
          <Button size="icon" disabled={!input.trim() || streaming} onClick={sendMessage}>
            {streaming ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AITutorGenerator;
