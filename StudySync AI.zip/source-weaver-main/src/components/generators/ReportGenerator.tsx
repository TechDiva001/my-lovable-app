import { useState } from "react";
import { Button } from "@/components/ui/button";
import { FileText, RefreshCw, Loader2 } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import ReactMarkdown from "react-markdown";
import { streamAI } from "@/lib/ai";
import { toast } from "sonner";

type Source = { id: string; type: string; name: string };
const reportTypes = ["Summary", "Detailed", "Study Notes"] as const;

const ReportGenerator = ({ hasSources, sources, onSave }: { hasSources: boolean; sources: Source[]; onSave?: (title: string, content: any) => void }) => {
  const [report, setReport] = useState("");
  const [reportType, setReportType] = useState<(typeof reportTypes)[number]>("Summary");
  const [generating, setGenerating] = useState(false);

  const handleGenerate = async () => {
    if (!hasSources) return;
    setGenerating(true);
    setReport("");
    try {
      const sourceNames = sources.map((s) => s.name).join(", ");
      const finalReport = await streamAI(
        [
          {
            role: "system",
            content: `Generate a ${reportType.toLowerCase()} report based on the user's study sources. Use markdown formatting with headers, bullet points, and sections. Be thorough and well-structured.`,
          },
          { role: "user", content: `Create a ${reportType.toLowerCase()} report from these sources: ${sourceNames}` },
        ],
        (text) => setReport(text)
      );
      onSave?.(`${reportType} Report - ${sourceNames.slice(0, 30)}`, { text: finalReport, type: reportType });
    } catch {
      toast.error("Failed to generate report");
    }
    setGenerating(false);
  };

  if (!report && !generating) {
    return (
      <div className="text-center py-8">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10">
          <FileText className="h-7 w-7 text-primary" />
        </div>
        <h3 className="font-display text-lg font-bold text-foreground mb-2">Report Generator</h3>
        <p className="text-muted-foreground text-sm mb-4">
          {hasSources ? "Generate structured reports." : "Add sources first."}
        </p>
        <div className="flex gap-2 justify-center mb-4">
          {reportTypes.map((t) => (
            <Button key={t} variant={reportType === t ? "default" : "outline"} size="sm" onClick={() => setReportType(t)}>
              {t}
            </Button>
          ))}
        </div>
        <Button onClick={handleGenerate} disabled={!hasSources || generating}>
          <FileText className="h-4 w-4 mr-1.5" /> Generate Report
        </Button>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display font-bold text-foreground">Report</h3>
        <Button variant="ghost" size="sm" onClick={handleGenerate} disabled={generating}>
          {generating ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}
        </Button>
      </div>
      <ScrollArea className="h-[400px]">
        <div className="prose prose-sm dark:prose-invert max-w-none rounded-xl border border-border/50 bg-card p-4">
          <ReactMarkdown>{report || "Generating..."}</ReactMarkdown>
        </div>
      </ScrollArea>
    </div>
  );
};

export default ReportGenerator;
