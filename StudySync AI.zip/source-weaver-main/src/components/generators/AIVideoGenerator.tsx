import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Video, Loader2, ChevronLeft, ChevronRight, Play, RotateCcw } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { generateAI } from "@/lib/ai";
import { toast } from "sonner";

type Source = { id: string; type: string; name: string };
type Slide = { title: string; narration: string; visual: string; keyPoints: string[] };

const AIVideoGenerator = ({ hasSources, sources, onSave }: { hasSources: boolean; sources: Source[]; onSave?: (title: string, content: any) => void }) => {
  const [slides, setSlides] = useState<Slide[]>([]);
  const [current, setCurrent] = useState(0);
  const [generating, setGenerating] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [autoPlayTimer, setAutoPlayTimer] = useState<ReturnType<typeof setInterval> | null>(null);

  const handleGenerate = async () => {
    if (!hasSources) return;
    setGenerating(true);
    try {
      const sourceNames = sources.map((s) => s.name).join(", ");
      const result = await generateAI([
        {
          role: "system",
          content: `Create an explainer video script as a slideshow. Return ONLY a JSON array of 6-8 slide objects. Each slide has: "title" (short headline), "narration" (2-3 sentence explanation), "visual" (description of what visual/diagram to show), "keyPoints" (array of 2-3 bullet points). No markdown, no code fences.`,
        },
        { role: "user", content: `Create an animated explainer video slideshow about: ${sourceNames}. Cover key concepts, include visual descriptions, and make narrations engaging.` },
      ]);
      const cleaned = result.replace(/```json?\n?/g, "").replace(/```/g, "").trim();
      const parsed = JSON.parse(cleaned);
      if (Array.isArray(parsed) && parsed.length > 0) {
        setSlides(parsed);
        setCurrent(0);
        toast.success("Video slides generated!");
        onSave?.(`Video - ${sourceNames.slice(0, 30)}`, parsed);
      }
    } catch {
      toast.error("Failed to generate video content");
    }
    setGenerating(false);
  };

  const startAutoPlay = () => {
    setPlaying(true);
    setCurrent(0);
    const timer = setInterval(() => {
      setCurrent((prev) => {
        if (prev >= slides.length - 1) {
          clearInterval(timer);
          setPlaying(false);
          return prev;
        }
        return prev + 1;
      });
    }, 6000);
    setAutoPlayTimer(timer);
  };

  const stopAutoPlay = () => {
    if (autoPlayTimer) clearInterval(autoPlayTimer);
    setPlaying(false);
  };

  if (!hasSources) {
    return (
      <div className="text-center py-10">
        <Video className="h-8 w-8 mx-auto mb-3 text-primary/40" />
        <p className="text-sm text-muted-foreground">Add sources to generate AI video explainers</p>
      </div>
    );
  }

  const slide = slides[current];

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-4">
        <Video className="h-5 w-5 text-primary" />
        <h3 className="font-display font-semibold text-slate-100">AI Video Overview</h3>
        <span className="text-xs bg-accent/10 text-accent px-2 py-0.5 rounded-full">Explainer</span>
      </div>

      <p className="text-xs text-muted-foreground">
        Generates animated slideshow explainer videos with narrated explanations, visual diagrams, and key highlights.
      </p>

      <Button onClick={handleGenerate} disabled={generating} className="w-full" variant="default">
        {generating ? <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Generating Slides...</> : <><RotateCcw className="h-4 w-4 mr-2" /> Generate Video Slides</>}
      </Button>

      {slides.length > 0 && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-3">
          {/* Slide viewer */}
          <div className="rounded-xl border border-white/10 bg-gradient-to-br from-primary/5 to-accent/5 overflow-hidden">
            {/* Slide counter bar */}
            <div className="flex gap-1 p-2 bg-black/20">
              {slides.map((_, i) => (
                <div key={i} className={`flex-1 h-1 rounded-full transition-colors ${i === current ? "bg-primary" : i < current ? "bg-primary/40" : "bg-white/10"}`} />
              ))}
            </div>

            <AnimatePresence mode="wait">
              {slide && (
                <motion.div
                  key={current}
                  initial={{ opacity: 0, x: 30 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -30 }}
                  transition={{ duration: 0.4 }}
                  className="p-5 space-y-4"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-xs bg-primary/20 text-primary px-2 py-0.5 rounded-full">Slide {current + 1}/{slides.length}</span>
                  </div>

                  <h4 className="font-display text-lg font-bold text-foreground">{slide.title}</h4>

                  {/* Visual description */}
                  <div className="rounded-lg bg-white/5 border border-white/10 p-3 flex items-center gap-3">
                    <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Video className="h-5 w-5 text-primary" />
                    </div>
                    <p className="text-xs text-muted-foreground italic">{slide.visual}</p>
                  </div>

                  {/* Narration */}
                  <p className="text-sm text-slate-300 leading-relaxed">{slide.narration}</p>

                  {/* Key points */}
                  <div className="space-y-1.5">
                    {slide.keyPoints?.map((point, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, x: 10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.15 }}
                        className="flex items-start gap-2"
                      >
                        <span className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="text-[10px] font-bold text-primary">{i + 1}</span>
                        </span>
                        <span className="text-sm text-slate-300">{point}</span>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-between">
            <Button size="sm" variant="ghost" onClick={() => setCurrent(Math.max(0, current - 1))} disabled={current === 0}>
              <ChevronLeft className="h-4 w-4 mr-1" /> Prev
            </Button>

            <Button size="sm" variant="outline" onClick={playing ? stopAutoPlay : startAutoPlay}>
              <Play className="h-3.5 w-3.5 mr-1" /> {playing ? "Stop" : "Auto Play"}
            </Button>

            <Button size="sm" variant="ghost" onClick={() => setCurrent(Math.min(slides.length - 1, current + 1))} disabled={current === slides.length - 1}>
              Next <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default AIVideoGenerator;
