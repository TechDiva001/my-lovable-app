import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Map, RefreshCw, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { generateAI } from "@/lib/ai";
import { toast } from "sonner";

type Source = { id: string; type: string; name: string };
type Node = { id: string; label: string; children?: Node[] };

const MindMapNode = ({ node, depth = 0 }: { node: Node; depth?: number }) => {
  const [expanded, setExpanded] = useState(true);
  const colors = ["bg-primary/10 text-primary border-primary/20", "bg-accent/10 text-accent border-accent/20", "bg-secondary text-secondary-foreground border-border/20"];

  return (
    <div className={`${depth > 0 ? "ml-6 border-l border-border/30 pl-4" : ""}`}>
      <motion.button
        initial={{ opacity: 0, x: -10 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: depth * 0.1 }}
        onClick={() => setExpanded(!expanded)}
        className={`rounded-lg border px-3 py-1.5 text-sm font-medium mb-2 transition-all hover:shadow-sm ${colors[Math.min(depth, 2)]}`}
      >
        {node.children && (expanded ? "▾ " : "▸ ")}
        {node.label}
      </motion.button>
      {expanded && node.children && (
        <div className="space-y-1">
          {node.children.map((child) => (
            <MindMapNode key={child.id} node={child} depth={depth + 1} />
          ))}
        </div>
      )}
    </div>
  );
};

const MindMapGenerator = ({ hasSources, sources, onSave }: { hasSources: boolean; sources: Source[]; onSave?: (title: string, content: any) => void }) => {
  const [mapData, setMapData] = useState<Node | null>(null);
  const [generating, setGenerating] = useState(false);

  const handleGenerate = async () => {
    if (!hasSources) return;
    setGenerating(true);
    try {
      const sourceNames = sources.map((s) => s.name).join(", ");
      const result = await generateAI([
        {
          role: "system",
          content: `Generate a hierarchical mind map based on the user's study sources. Return ONLY valid JSON with this structure: {"id":"root","label":"Main Topic","children":[{"id":"1","label":"Subtopic","children":[...]}]}. Max 3 levels deep, 3-5 children per node. No markdown, no code fences.`,
        },
        { role: "user", content: `Create a mind map from these sources: ${sourceNames}` },
      ]);
      const cleaned = result.replace(/```json?\n?/g, "").replace(/```/g, "").trim();
      const parsed = JSON.parse(cleaned);
      if (parsed && parsed.label) {
        setMapData(parsed);
        onSave?.(parsed.label || `Mind Map - ${sourceNames.slice(0, 30)}`, parsed);
      } else {
        toast.error("Failed to parse mind map");
      }
    } catch {
      toast.error("Failed to generate mind map");
    }
    setGenerating(false);
  };

  if (!mapData) {
    return (
      <div className="text-center py-8">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10">
          <Map className="h-7 w-7 text-primary" />
        </div>
        <h3 className="font-display text-lg font-bold text-foreground mb-2">Mind Map</h3>
        <p className="text-muted-foreground text-sm mb-6">
          {hasSources ? "Generate an interactive mind map." : "Add sources first."}
        </p>
        <Button onClick={handleGenerate} disabled={!hasSources || generating}>
          {generating ? <Loader2 className="h-4 w-4 animate-spin mr-1.5" /> : <Map className="h-4 w-4 mr-1.5" />}
          {generating ? "Generating..." : "Generate Mind Map"}
        </Button>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display font-bold text-foreground">Mind Map</h3>
        <Button variant="ghost" size="sm" onClick={handleGenerate} disabled={generating}>
          {generating ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}
        </Button>
      </div>
      <MindMapNode node={mapData} />
    </div>
  );
};

export default MindMapGenerator;
