import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Layers, ChevronLeft, ChevronRight, RefreshCw, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { generateAI } from "@/lib/ai";
import { toast } from "sonner";

type Source = { id: string; type: string; name: string };
type Slide = { title: string; bullets: string[]; notes?: string };

const SlideGenerator = ({ hasSources, sources, onSave }: { hasSources: boolean; sources: Source[]; onSave?: (title: string, content: any) => void }) => {
  const [slides, setSlides] = useState<Slide[]>([]);
  const [current, setCurrent] = useState(0);
  const [generating, setGenerating] = useState(false);

  const handleGenerate = async () => {
    if (!hasSources) return;
    setGenerating(true);
    try {
      const sourceNames = sources.map((s) => s.name).join(", ");
      const result = await generateAI([
        {
          role: "system",
          content: `Generate a 5-slide presentation deck based on the user's study sources. Return ONLY a JSON array of objects with keys: "title" (string), "bullets" (array of 3-4 strings), "notes" (optional string). No markdown, no code fences.`,
        },
        { role: "user", content: `Create slides from these sources: ${sourceNames}` },
      ]);
      const cleaned = result.replace(/```json?\n?/g, "").replace(/```/g, "").trim();
      const parsed = JSON.parse(cleaned);
      if (Array.isArray(parsed) && parsed.length > 0) {
        setSlides(parsed);
        setCurrent(0);
        onSave?.(`Slides - ${sourceNames.slice(0, 30)}`, parsed);
      } else {
        toast.error("Failed to parse slides");
      }
    } catch {
      toast.error("Failed to generate slides");
    }
    setGenerating(false);
  };

  if (slides.length === 0) {
    return (
      <div className="text-center py-8">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10">
          <Layers className="h-7 w-7 text-primary" />
        </div>
        <h3 className="font-display text-lg font-bold text-foreground mb-2">Slide Deck</h3>
        <p className="text-muted-foreground text-sm mb-6">
          {hasSources ? "Generate presentation slides." : "Add sources first."}
        </p>
        <Button onClick={handleGenerate} disabled={!hasSources || generating}>
          {generating ? <Loader2 className="h-4 w-4 animate-spin mr-1.5" /> : <Layers className="h-4 w-4 mr-1.5" />}
          {generating ? "Generating..." : "Generate Slides"}
        </Button>
      </div>
    );
  }

  const slide = slides[current];
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display font-bold text-sm text-foreground">Slide {current + 1}/{slides.length}</h3>
        <Button variant="ghost" size="sm" onClick={handleGenerate} disabled={generating}>
          {generating ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}
        </Button>
      </div>
      <AnimatePresence mode="wait">
        <motion.div
          key={current}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="rounded-xl border border-border/50 bg-card overflow-hidden"
        >
          <div className="bg-primary/5 p-4 border-b border-border/50">
            <h4 className="font-display font-bold text-foreground">{slide.title}</h4>
          </div>
          <div className="p-4">
            <ul className="space-y-2">
              {slide.bullets.map((b, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-foreground">
                  <span className="text-primary mt-0.5">•</span> {b}
                </li>
              ))}
            </ul>
            {slide.notes && (
              <p className="mt-4 text-xs text-muted-foreground italic border-t border-border/50 pt-3">
                Speaker notes: {slide.notes}
              </p>
            )}
          </div>
        </motion.div>
      </AnimatePresence>
      <div className="flex items-center justify-center gap-3 mt-4">
        <Button variant="outline" size="icon" onClick={() => setCurrent(Math.max(0, current - 1))} disabled={current === 0}>
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <Button variant="outline" size="icon" onClick={() => setCurrent(Math.min(slides.length - 1, current + 1))} disabled={current === slides.length - 1}>
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
};

export default SlideGenerator;
