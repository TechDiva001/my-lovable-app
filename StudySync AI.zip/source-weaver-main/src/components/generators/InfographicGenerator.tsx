import { useState } from "react";
import { Button } from "@/components/ui/button";
import { BarChart3, RefreshCw, Loader2 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { generateAI } from "@/lib/ai";
import { toast } from "sonner";

type Source = { id: string; type: string; name: string };
const COLORS = ["hsl(172, 66%, 50%)", "hsl(36, 95%, 55%)", "hsl(262, 60%, 55%)", "hsl(340, 75%, 55%)", "hsl(200, 80%, 50%)"];

const InfographicGenerator = ({ hasSources, sources, onSave }: { hasSources: boolean; sources: Source[]; onSave?: (title: string, content: any) => void }) => {
  const [data, setData] = useState<{ bar: { name: string; value: number }[]; pie: { name: string; value: number }[] } | null>(null);
  const [generating, setGenerating] = useState(false);

  const handleGenerate = async () => {
    if (!hasSources) return;
    setGenerating(true);
    try {
      const sourceNames = sources.map((s) => s.name).join(", ");
      const result = await generateAI([
        {
          role: "system",
          content: `Analyze the user's study sources and generate chart data. Return ONLY valid JSON: {"bar":[{"name":"Topic","value":85}],"pie":[{"name":"Category","value":30}]}. 5-6 items per chart. Values should be meaningful percentages or scores. No markdown, no code fences.`,
        },
        { role: "user", content: `Create infographic data from these sources: ${sourceNames}` },
      ]);
      const cleaned = result.replace(/```json?\n?/g, "").replace(/```/g, "").trim();
      const parsed = JSON.parse(cleaned);
      if (parsed.bar && parsed.pie) {
        setData(parsed);
        onSave?.(`Infographic - ${sourceNames.slice(0, 30)}`, parsed);
      } else {
        toast.error("Failed to parse chart data");
      }
    } catch {
      toast.error("Failed to generate infographic");
    }
    setGenerating(false);
  };

  if (!data) {
    return (
      <div className="text-center py-8">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10">
          <BarChart3 className="h-7 w-7 text-primary" />
        </div>
        <h3 className="font-display text-lg font-bold text-foreground mb-2">Infographic</h3>
        <p className="text-muted-foreground text-sm mb-6">
          {hasSources ? "Generate visual charts and infographics." : "Add sources first."}
        </p>
        <Button onClick={handleGenerate} disabled={!hasSources || generating}>
          {generating ? <Loader2 className="h-4 w-4 animate-spin mr-1.5" /> : <BarChart3 className="h-4 w-4 mr-1.5" />}
          {generating ? "Generating..." : "Generate Infographic"}
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="font-display font-bold text-foreground">Infographic</h3>
        <Button variant="ghost" size="sm" onClick={handleGenerate} disabled={generating}>
          {generating ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}
        </Button>
      </div>
      <div className="rounded-xl border border-border/50 bg-card p-4">
        <h4 className="font-display font-semibold text-sm text-foreground mb-3">Key Topics</h4>
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={data.bar}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
            <XAxis dataKey="name" tick={{ fontSize: 11 }} className="fill-muted-foreground" />
            <YAxis tick={{ fontSize: 11 }} className="fill-muted-foreground" />
            <RechartsTooltip />
            <Bar dataKey="value" fill="hsl(172, 66%, 50%)" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="rounded-xl border border-border/50 bg-card p-4">
        <h4 className="font-display font-semibold text-sm text-foreground mb-3">Distribution</h4>
        <ResponsiveContainer width="100%" height={180}>
          <PieChart>
            <Pie data={data.pie} dataKey="value" cx="50%" cy="50%" outerRadius={70} label={({ name }) => name}>
              {data.pie.map((_, idx) => <Cell key={idx} fill={COLORS[idx % COLORS.length]} />)}
            </Pie>
            <RechartsTooltip />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default InfographicGenerator;
