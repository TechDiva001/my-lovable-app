import { useState } from "react";
import { Button } from "@/components/ui/button";
import { BookOpen, RotateCcw, ChevronLeft, ChevronRight, RefreshCw, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { generateAI } from "@/lib/ai";
import { toast } from "sonner";

type Source = { id: string; type: string; name: string };

const FlashcardGenerator = ({ hasSources, sources, onSave }: { hasSources: boolean; sources: Source[]; onSave?: (title: string, content: any) => void }) => {
  const [cards, setCards] = useState<{ q: string; a: string }[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [generating, setGenerating] = useState(false);

  const handleGenerate = async () => {
    if (!hasSources) return;
    setGenerating(true);
    try {
      const sourceNames = sources.map((s) => s.name).join(", ");
      const result = await generateAI([
        {
          role: "system",
          content: `Generate exactly 8 flashcards based on the user's study sources. Return ONLY a valid JSON array of objects with "q" (question) and "a" (answer) keys. No markdown, no code fences, just the JSON array.`,
        },
        { role: "user", content: `Create flashcards from these sources: ${sourceNames}` },
      ]);
      const cleaned = result.replace(/```json?\n?/g, "").replace(/```/g, "").trim();
      const parsed = JSON.parse(cleaned);
      if (Array.isArray(parsed) && parsed.length > 0) {
        setCards(parsed);
        setCurrentIndex(0);
        setFlipped(false);
        onSave?.(`Flashcards - ${sourceNames.slice(0, 30)}`, parsed);
      } else {
        toast.error("Failed to parse flashcards");
      }
    } catch {
      toast.error("Failed to generate flashcards");
    }
    setGenerating(false);
  };

  if (cards.length === 0) {
    return (
      <div className="text-center py-8">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10">
          <BookOpen className="h-7 w-7 text-primary" />
        </div>
        <h3 className="font-display text-lg font-bold text-foreground mb-2">Flashcard Generator</h3>
        <p className="text-muted-foreground text-sm mb-6">
          {hasSources ? "Generate study flashcards from your sources." : "Add sources first to generate flashcards."}
        </p>
        <Button onClick={handleGenerate} disabled={!hasSources || generating}>
          {generating ? <Loader2 className="h-4 w-4 animate-spin mr-1.5" /> : <BookOpen className="h-4 w-4 mr-1.5" />}
          {generating ? "Generating..." : "Generate Flashcards"}
        </Button>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display font-bold text-foreground">Flashcards</h3>
        <span className="text-xs text-muted-foreground">{currentIndex + 1} / {cards.length}</span>
      </div>

      <div
        onClick={() => setFlipped(!flipped)}
        className="cursor-pointer rounded-xl border border-border/50 bg-card p-6 min-h-[200px] flex items-center justify-center text-center transition-all hover:shadow-glow"
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={flipped ? "a" : "q"}
            initial={{ rotateY: 90, opacity: 0 }}
            animate={{ rotateY: 0, opacity: 1 }}
            exit={{ rotateY: -90, opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            <p className="text-xs text-muted-foreground mb-2">{flipped ? "Answer" : "Question"}</p>
            <p className="font-display font-semibold text-foreground">{flipped ? cards[currentIndex].a : cards[currentIndex].q}</p>
          </motion.div>
        </AnimatePresence>
      </div>

      <p className="text-center text-xs text-muted-foreground mt-2">Click to flip</p>

      <div className="flex items-center justify-center gap-3 mt-4">
        <Button variant="outline" size="icon" onClick={() => { setCurrentIndex(Math.max(0, currentIndex - 1)); setFlipped(false); }} disabled={currentIndex === 0}>
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <Button variant="outline" size="icon" onClick={() => { setFlipped(false); }}>
          <RotateCcw className="h-4 w-4" />
        </Button>
        <Button variant="outline" size="icon" onClick={() => { setCurrentIndex(Math.min(cards.length - 1, currentIndex + 1)); setFlipped(false); }} disabled={currentIndex === cards.length - 1}>
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      <Button variant="ghost" className="w-full mt-4 text-xs" onClick={handleGenerate} disabled={generating}>
        {generating ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1" /> : <RefreshCw className="h-3.5 w-3.5 mr-1" />}
        Regenerate
      </Button>
    </div>
  );
};

export default FlashcardGenerator;
