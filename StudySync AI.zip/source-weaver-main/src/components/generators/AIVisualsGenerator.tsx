import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Eye, Loader2, RotateCcw } from "lucide-react";
import { motion } from "framer-motion";
import { generateAI } from "@/lib/ai";
import { toast } from "sonner";
import { BarChart, Bar, XAxis, YAxis, Tooltip as RTooltip, PieChart, Pie, Cell, LineChart, Line, ResponsiveContainer, CartesianGrid } from "recharts";

type Source = { id: string; type: string; name: string };
type VisualizationData = {
  title: string;
  description: string;
  chartType: "bar" | "pie" | "line" | "timeline";
  data: { name: string; value: number; color?: string }[];
  insights: string[];
};

const CHART_COLORS = ["hsl(var(--primary))", "hsl(var(--accent))", "#6366f1", "#f59e0b", "#10b981", "#ef4444", "#8b5cf6", "#ec4899"];

const AIVisualsGenerator = ({ hasSources, sources, onSave }: { hasSources: boolean; sources: Source[]; onSave?: (title: string, content: any) => void }) => {
  const [mode, setMode] = useState<"select" | "short" | "full" | null>(null);
  const [customText, setCustomText] = useState("");
  const [visualization, setVisualization] = useState<VisualizationData | null>(null);
  const [generating, setGenerating] = useState(false);

  const handleGenerate = async (text: string, isFullSource: boolean) => {
    setGenerating(true);
    try {
      const prompt = isFullSource
        ? `Analyze these study sources and create a data visualization: ${sources.map((s) => s.name).join(", ")}. Identify quantifiable concepts, comparisons, or relationships and visualize them.`
        : `Create a data visualization for this text:\n\n${text}`;

      const result = await generateAI([
        {
          role: "system",
          content: `You create data visualizations from educational content. Return ONLY valid JSON with: "title" (string), "description" (1-2 sentences), "chartType" ("bar"|"pie"|"line"), "data" (array of {"name": string, "value": number}), "insights" (array of 2-3 string insights). Extract or infer numerical data from the content. If no obvious numbers, create comparative ratings (1-10 scale). No markdown, no code fences.`,
        },
        { role: "user", content: prompt },
      ]);

      const cleaned = result.replace(/```json?\n?/g, "").replace(/```/g, "").trim();
      const parsed = JSON.parse(cleaned);
      setVisualization(parsed);
      toast.success("Visualization created!");
      onSave?.(parsed.title || "AI Visualization", parsed);
    } catch {
      toast.error("Failed to generate visualization");
    }
    setGenerating(false);
  };

  if (!hasSources) {
    return (
      <div className="text-center py-10">
        <Eye className="h-8 w-8 mx-auto mb-3 text-primary/40" />
        <p className="text-sm text-muted-foreground">Add sources to create AI visualizations</p>
      </div>
    );
  }

  if (!mode) {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2 mb-4">
          <Eye className="h-5 w-5 text-primary" />
          <h3 className="font-display font-semibold text-slate-100">AI Visuals</h3>
        </div>
        <p className="text-xs text-muted-foreground">
          Create data visualizations from your study content. Choose how to visualize:
        </p>
        <div className="space-y-3">
          <button
            onClick={() => setMode("short")}
            className="w-full rounded-xl border border-primary/30 bg-primary/10 p-4 text-left hover:bg-primary/20 hover:shadow-[0_0_15px_hsl(var(--primary)/0.3)] hover:scale-[1.02] transition-all duration-200"
          >
            <h4 className="font-semibold text-sm text-slate-100 mb-1">📝 Visualize a Short Part</h4>
            <p className="text-xs text-slate-400">Paste or type a specific section to visualize</p>
          </button>
          <button
            onClick={() => setMode("full")}
            className="w-full rounded-xl border border-primary/30 bg-primary/10 p-4 text-left hover:bg-primary/20 hover:shadow-[0_0_15px_hsl(var(--primary)/0.3)] hover:scale-[1.02] transition-all duration-200"
          >
            <h4 className="font-semibold text-sm text-slate-100 mb-1">📊 Visualize Selected Sources</h4>
            <p className="text-xs text-slate-400">AI analyzes your entire source material and creates visuals</p>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-2">
        <Eye className="h-5 w-5 text-primary" />
        <h3 className="font-display font-semibold text-slate-100">AI Visuals</h3>
        <Button size="sm" variant="ghost" onClick={() => { setMode(null); setVisualization(null); }} className="ml-auto text-xs">
          ← Back
        </Button>
      </div>

      {mode === "short" && !visualization && (
        <div className="space-y-3">
          <Textarea
            placeholder="Paste the text or content you want to visualize..."
            value={customText}
            onChange={(e) => setCustomText(e.target.value)}
            className="min-h-[120px] bg-white/10 border-white/10 text-slate-200 placeholder:text-slate-500"
          />
          <Button onClick={() => handleGenerate(customText, false)} disabled={generating || !customText.trim()} className="w-full" variant="default">
            {generating ? <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Creating...</> : <><Eye className="h-4 w-4 mr-2" /> Generate Visualization</>}
          </Button>
        </div>
      )}

      {mode === "full" && !visualization && (
        <div className="space-y-3">
          <div className="rounded-lg bg-white/5 border border-white/10 p-3">
            <p className="text-xs text-muted-foreground mb-2">Sources to visualize:</p>
            {sources.map((s) => (
              <p key={s.id} className="text-sm text-slate-300">• {s.name}</p>
            ))}
          </div>
          <Button onClick={() => handleGenerate("", true)} disabled={generating} className="w-full" variant="default">
            {generating ? <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Analyzing Sources...</> : <><Eye className="h-4 w-4 mr-2" /> Visualize Sources</>}
          </Button>
        </div>
      )}

      {visualization && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
          <h4 className="font-display font-bold text-white">{visualization.title}</h4>
          <p className="text-xs text-muted-foreground">{visualization.description}</p>

          {/* Chart */}
          <div className="rounded-xl border border-white/10 bg-white/5 p-4">
            <ResponsiveContainer width="100%" height={220}>
              {visualization.chartType === "pie" ? (
                <PieChart>
                  <Pie data={visualization.data} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label={({ name }) => name}>
                    {visualization.data.map((_, i) => (
                      <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                    ))}
                  </Pie>
                  <RTooltip />
                </PieChart>
              ) : visualization.chartType === "line" ? (
                <LineChart data={visualization.data}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                  <XAxis dataKey="name" tick={{ fontSize: 10, fill: "#94a3b8" }} />
                  <YAxis tick={{ fontSize: 10, fill: "#94a3b8" }} />
                  <RTooltip />
                  <Line type="monotone" dataKey="value" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ fill: "hsl(var(--primary))" }} />
                </LineChart>
              ) : (
                <BarChart data={visualization.data}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                  <XAxis dataKey="name" tick={{ fontSize: 10, fill: "#94a3b8" }} />
                  <YAxis tick={{ fontSize: 10, fill: "#94a3b8" }} />
                  <RTooltip />
                  <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                    {visualization.data.map((_, i) => (
                      <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              )}
            </ResponsiveContainer>
          </div>

          {/* Insights */}
          <div className="space-y-2">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Key Insights</p>
            {visualization.insights?.map((insight, i) => (
              <motion.div key={i} initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.1 }} className="flex items-start gap-2">
                <span className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-[10px] font-bold text-primary">{i + 1}</span>
                </span>
                <span className="text-sm text-slate-300">{insight}</span>
              </motion.div>
            ))}
          </div>

          <Button onClick={() => setVisualization(null)} variant="ghost" size="sm" className="w-full">
            <RotateCcw className="h-3.5 w-3.5 mr-1.5" /> Create Another
          </Button>
        </motion.div>
      )}
    </div>
  );
};

export default AIVisualsGenerator;
